namespace AsaderoRegio;

public sealed partial class PedidosPage : Page
{
    Cuenta _cuenta;
    bool _cargando;
    bool _soloLectura;   // Cajero y cocina pueden consultar el menú pero no pedir nada
    List<Producto> _todos = new();
    readonly HashSet<object> _hover = new();

    class Detalle
    {
        public Opcion Opcion;
        public List<string> Guarniciones = new();
        public int Cantidad = 1;
        public string Notas = "";
    }

    public PedidosPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        _soloLectura = Datos.Sesion?.Rol is Roles.Cajero or Roles.Cocina;
        _cuenta = _soloLectura ? null : e.Parameter as Cuenta;
        if (_cuenta != null && _cuenta.Estado != "Abierta") _cuenta = null;
        _todos = Datos.Productos.Where(p => p.Activo).OrderBy(p => p.Categoria).ThenBy(p => p.Nombre).ToList();

        _cargando = true;
        CmbCategoria.Items.Clear();
        CmbCategoria.Items.Add("Todas");
        foreach (var c in _todos.Select(p => p.Categoria).Distinct()) CmbCategoria.Items.Add(c);
        CmbCategoria.SelectedIndex = 0;
        CargarCuentas();
        _cargando = false;

        AplicarModo();
        Filtrar();
        Refrescar();
        Anim.Enter(PanelProductos, 0);
        if (!_soloLectura) Anim.Enter(PanelCuenta, 120);
    }

    /// <summary>Modo consulta (cajero): solo se ve el menú; sin cuenta, sin seleccionar platillos.</summary>
    void AplicarModo()
    {
        var ver = _soloLectura ? Visibility.Collapsed : Visibility.Visible;
        PanelCuenta.Visibility = ver;
        CmbCuenta.Visibility = ver;
        ColCuenta.Width = _soloLectura ? new GridLength(0) : new GridLength(2, GridUnitType.Star);
        ColCuenta.MinWidth = _soloLectura ? 0 : 420;
        Productos.IsItemClickEnabled = !_soloLectura;
        TxtModo.Visibility = _soloLectura ? Visibility.Visible : Visibility.Collapsed;
    }

    void CargarCuentas()
    {
        var ab = Datos.Cuentas.Where(c => c.Estado == "Abierta").OrderBy(c => c.FechaApertura).ToList();
        CmbCuenta.ItemsSource = ab;
        CmbCuenta.SelectedItem = _cuenta;
    }

    void CmbCuenta_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_cargando) return;
        _cuenta = CmbCuenta.SelectedItem as Cuenta;
        Refrescar();
    }

    void Filtro_Changed(object sender, SelectionChangedEventArgs e) { if (!_cargando) Filtrar(); }
    void Filtro_Changed2(object sender, TextChangedEventArgs e) { if (!_cargando) Filtrar(); }

    void Filtrar()
    {
        var cat = CmbCategoria.SelectedItem as string;
        var txt = (TxtBuscar.Text ?? "").Trim();
        var q = _todos.AsEnumerable();
        if (!string.IsNullOrEmpty(cat) && cat != "Todas") q = q.Where(p => p.Categoria == cat);
        if (txt.Length > 0) q = q.Where(p => p.Nombre.Contains(txt, StringComparison.OrdinalIgnoreCase));
        Productos.ItemsSource = q.ToList();
    }

    void Productos_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs a)
    {
        if (a.InRecycleQueue || a.Phase != 0) return;
        Anim.Enter(a.ItemContainer, Math.Min(a.ItemIndex, 12) * 25, 14);
        if (!_soloLectura && _hover.Add(a.ItemContainer))
        {
            a.ItemContainer.PointerEntered += (o, _) => Anim.Scale((UIElement)o, 1.05);
            a.ItemContainer.PointerExited += (o, _) => Anim.Scale((UIElement)o, 1.0);
        }
    }

    void Refrescar()
    {
        if (_cuenta == null)
        {
            PanelVacio.Visibility = Visibility.Visible;
            PanelDetalle.Visibility = Visibility.Collapsed;
            return;
        }
        PanelVacio.Visibility = Visibility.Collapsed;
        PanelDetalle.Visibility = Visibility.Visible;
        TxtTitulo.Text = _cuenta.Titulo;
        TxtSub.Text = $"{_cuenta.Folio} · {_cuenta.Personas} pers. · Atiende: {_cuenta.Mesero} · {_cuenta.EstadoMesero}";
        ListaItems.ItemsSource = _cuenta.ItemsActivos.ToList();
        TxtSubtotal.Text = Fmt.Money(_cuenta.Subtotal);
        TxtTotal.Text = Fmt.Money(_cuenta.Total);
        // El botón se apaga cuando no hay nada nuevo por enviar
        BtnCocina.IsEnabled = _cuenta.ItemsActivos.Any(i => !i.Enviado) && !_cuenta.SolicitoCuenta;
    }

    void Guardar()
    {
        Datos.GuardarCuentas();
        Refrescar();
        Anim.Pop(TxtTotal);
    }

    void IrMesas_Click(object sender, RoutedEventArgs e) => ShellPage.Actual.IrA("mesas");

    async void Producto_ItemClick(object sender, ItemClickEventArgs e)
    {
        if (_soloLectura) return;
        var p = (Producto)e.ClickedItem;
        if (_cuenta == null) { Notificador.Mostrar("Primero abre o selecciona una cuenta.", false); return; }
        if (_cuenta.SolicitoCuenta) { Notificador.Mostrar("La cuenta ya está por cobrar; no se pueden agregar productos.", false); return; }
        if (p.SinOpcionesDisponibles) { Notificador.Mostrar($"{p.Nombre} no tiene opciones disponibles por el momento.", false); return; }

        if (p.OpcionesActivas.Count == 0 && p.Guarniciones == 0)
        {
            var (falta, aviso) = Datos.RevisarStock(p, 1, 1);
            if (falta != null) { Notificador.Mostrar($"No hay suficiente {falta} para preparar {p.Nombre}.", false); return; }
            Datos.AgregarItem(_cuenta, p, null, null, 1, "");
            Guardar();
            if (aviso != null) Notificador.Mostrar($"Aviso: insumos bajos ({aviso}).", false);
            return;
        }
        var det = await PedirDetalle(p);
        if (det == null) return;
        var (f2, a2) = Datos.RevisarStock(p, det.Opcion?.Factor ?? 1, det.Cantidad);
        if (f2 != null) { Notificador.Mostrar($"No hay suficiente {f2} para preparar {det.Cantidad} × {p.Nombre}.", false); return; }
        Datos.AgregarItem(_cuenta, p, det.Opcion, det.Guarniciones, det.Cantidad, det.Notas);
        Guardar();
        if (a2 != null) Notificador.Mostrar($"Aviso: insumos bajos ({a2}).", false);
    }

    async Task<Detalle> PedirDetalle(Producto p)
    {
        var panel = new StackPanel { Spacing = 10, MinWidth = 400 };
        RadioButtons rb = null;
        var opcionesDisp = p.OpcionesActivas;
        if (opcionesDisp.Count > 0)
        {
            rb = new RadioButtons { Header = "Elige una opción" };
            foreach (var o in opcionesDisp) rb.Items.Add($"{o.Nombre} — {Fmt.Money(o.Precio)}");
            rb.SelectedIndex = 0;
            panel.Children.Add(rb);
        }
        var checks = new List<CheckBox>();
        ContentDialog d = null;
        if (p.Guarniciones > 0)
        {
            panel.Children.Add(new TextBlock { Text = $"Elige {p.Guarniciones} guarniciones", FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = Paleta.Amarillo });
            foreach (var g in Datos.Config.Guarniciones)
            {
                var cb = new CheckBox { Content = g };
                cb.Checked += Cambio; cb.Unchecked += Cambio;
                checks.Add(cb); panel.Children.Add(cb);
            }
        }
        void Cambio(object s, RoutedEventArgs a)
        {
            int n = checks.Count(c => c.IsChecked == true);
            foreach (var c in checks) c.IsEnabled = c.IsChecked == true || n < p.Guarniciones;
            if (d != null) d.IsPrimaryButtonEnabled = n == p.Guarniciones;
        }
        var cant = Campo.Num("Cantidad (1 a 50)", 1, true, 2);
        var notas = Campo.Texto("Notas para cocina (opcional)", "", "sin cebolla, término medio…");
        var err = Dialogos.EtiquetaError();
        panel.Children.Add(cant); panel.Children.Add(notas); panel.Children.Add(err);

        int cantidad = 1;
        d = Dialogos.Nuevo(XamlRoot, $"{p.Emoji} {p.Nombre}", panel, "Agregar");
        d.IsPrimaryButtonEnabled = p.Guarniciones == 0;
        Dialogos.Validar(d, err, () =>
        {
            var m = Campo.Validar(cant, "Cantidad", 1, 50, true, out var v);
            if (m != null) return m;
            cantidad = (int)v; return null;
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return null;
        return new Detalle
        {
            Opcion = rb != null && rb.SelectedIndex >= 0 ? opcionesDisp[rb.SelectedIndex] : null,
            Guarniciones = checks.Where(c => c.IsChecked == true).Select(c => (string)c.Content).ToList(),
            Cantidad = cantidad,
            Notas = notas.Text.Trim()
        };
    }

    async void Mas_Click(object sender, RoutedEventArgs e)
    {
        var it = (ItemPedido)((Button)sender).Tag;
        var p = Datos.Productos.FirstOrDefault(x => x.Id == it.ProductoId);
        if (p != null)
        {
            var (falta, _) = Datos.RevisarStock(p, it.Factor, 1);
            if (falta != null) { Notificador.Mostrar($"No hay suficiente {falta} para otra porción.", false); return; }
        }
        it.Cantidad++;
        Guardar();
        await Task.CompletedTask;
    }

    void Menos_Click(object sender, RoutedEventArgs e)
    {
        var it = (ItemPedido)((Button)sender).Tag;
        if (it.Cantidad > 1) { it.Cantidad--; Guardar(); }
        else Notificador.Mostrar("Usa ✖ para cancelar el platillo.", false);
    }

    /// <summary>Cancela unidades de un platillo: se elige cuáles renglones (opciones) y cuántas piezas.</summary>
    async void Quitar_Click(object sender, RoutedEventArgs e)
    {
        var clic = (ItemPedido)((Button)sender).Tag;
        var renglones = _cuenta.ItemsActivos.Where(i => i.ProductoId == clic.ProductoId).ToList();
        var panel = new StackPanel { Spacing = 10, MinWidth = 420 };
        panel.Children.Add(new TextBlock { Text = "Indica cuántas piezas cancelar de cada opción (deja en 0 las que se quedan).", TextWrapping = TextWrapping.Wrap });
        var campos = new List<(ItemPedido it, TextBox tb)>();
        foreach (var r in renglones)
        {
            var tb = Campo.Num($"{r.Descripcion} — pedidas: {r.Cantidad}" + (r.Enviado ? " (ya enviadas a cocina)" : ""), r == clic ? 1 : 0, true, 2);
            campos.Add((r, tb)); panel.Children.Add(tb);
        }
        var err = Dialogos.EtiquetaError();
        panel.Children.Add(err);
        var d = Dialogos.Nuevo(XamlRoot, "Cancelar platillo", panel, "Cancelar seleccionados");
        var plan = new List<(ItemPedido, int)>();
        Dialogos.Validar(d, err, () =>
        {
            plan.Clear();
            foreach (var (it, tb) in campos)
            {
                var m = Campo.NoNegativo(tb, it.Descripcion, out var v, it.Cantidad);
                if (m != null) return m;
                if (v > 0) plan.Add((it, (int)v));
            }
            return plan.Count == 0 ? "Indica al menos una pieza a cancelar." : null;
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        foreach (var (it, n) in plan) Datos.CancelarUnidades(_cuenta, it, n);
        Guardar();
        Notificador.Mostrar("Platillo cancelado.");
    }

    async void Nota_Click(object sender, RoutedEventArgs e)
    {
        var it = (ItemPedido)((Button)sender).Tag;
        var t = Campo.Texto("Notas para cocina", it.Notas, "sin cebolla, término medio…");
        var d = Dialogos.Nuevo(XamlRoot, it.Nombre, t, "Guardar");
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        it.Notas = t.Text.Trim();
        Guardar();
    }

    void Cocina_Click(object sender, RoutedEventArgs e)
    {
        if (_cuenta == null) return;
        int n = Datos.EnviarACocina(_cuenta);
        if (n == 0) { Notificador.Mostrar("No hay platillos nuevos por enviar.", false); return; }
        Refrescar();
        Notificador.Mostrar($"Comanda enviada a cocina ({n} platillos).");
    }
}
