namespace AsaderoRegio;

public sealed partial class UsuariosPage : Page
{
    public UsuariosPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        Cargar();
        Anim.Enter(Lista, 60);
    }

    void Cargar() => Lista.ItemsSource = Datos.Usuarios.OrderBy(u => u.Nombre).ToList();

    void Nuevo_Click(object sender, RoutedEventArgs e) => _ = Editar(null);
    void Editar_Click(object sender, RoutedEventArgs e) => _ = Editar((Usuario)((Button)sender).Tag);

    async Task Editar(Usuario u)
    {
        bool nuevo = u == null;
        var nombre = Campo.Texto("Nombre completo", u?.Nombre);
        var user = Campo.Texto("Usuario (para iniciar sesión)", u?.NombreUsuario);
        var rol = new ComboBox { Header = "Rol", HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var r in Roles.Todos) rol.Items.Add(r);
        rol.SelectedItem = u?.Rol ?? Roles.Mesero;
        var activo = new ToggleSwitch { Header = "Activo", IsOn = u?.Activo ?? true };
        var pass = new PasswordBox { Header = nuevo ? "Contraseña (mínimo 6 caracteres)" : "Nueva contraseña (vacío = no cambiar)" };
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 380 };
        foreach (var c in new UIElement[] { nombre, user, rol, activo, pass, err }) panel.Children.Add(c);
        var d = Dialogos.Nuevo(XamlRoot, nuevo ? "Nuevo usuario" : "Editar usuario", panel);
        Dialogos.Validar(d, err, () =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text) || string.IsNullOrWhiteSpace(user.Text)) return "Nombre y usuario son obligatorios.";
            if (Datos.Usuarios.Any(x => x != u && x.NombreUsuario.Equals(user.Text.Trim(), StringComparison.OrdinalIgnoreCase))) return "Ese nombre de usuario ya existe.";
            if ((nuevo || pass.Password.Length > 0) && pass.Password.Length < 6) return "La contraseña debe tener al menos 6 caracteres.";
            if (!nuevo)
            {
                bool seraAdminActivo = (string)rol.SelectedItem == Roles.Admin && activo.IsOn;
                if (!seraAdminActivo && Datos.Usuarios.Count(x => x.Rol == Roles.Admin && x.Activo && x != u) == 0 && u.Rol == Roles.Admin && u.Activo)
                    return "Debe quedar al menos un administrador activo.";
                if (u == Datos.Sesion && !activo.IsOn) return "No puedes desactivar tu propio usuario.";
            }
            return null;
        }, () =>
        {
            if (nuevo) { u = new Usuario { Id = Datos.Siguiente(Datos.Usuarios.Select(x => x.Id)) }; Datos.Usuarios.Add(u); }
            u.Nombre = nombre.Text.Trim(); u.NombreUsuario = user.Text.Trim(); u.Rol = (string)rol.SelectedItem; u.Activo = activo.IsOn;
            if (pass.Password.Length > 0) Datos.FijarPassword(u, pass.Password);
            Datos.GuardarUsuarios();
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Cargar();
        Notificador.Mostrar(nuevo ? "Usuario creado." : "Usuario actualizado.");
    }
}
