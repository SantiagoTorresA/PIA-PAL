namespace AsaderoRegio;

public sealed partial class InventarioPage : Page
{
    public InventarioPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        Cargar();
        Anim.Enter(Lista, 60);
        Anim.Enter(ListaMov, 160);
    }

    void Tgl_Toggled(object sender, RoutedEventArgs e) { if (Lista != null) Cargar(); }

    void Cargar()
    {
        var q = Datos.Ingredientes.AsEnumerable();
        if (TglBajo.IsOn) q = q.Where(i => i.Activo && i.Bajo);
        Lista.ItemsSource = q.OrderByDescending(i => i.Activo && i.Bajo).ThenBy(i => i.Nombre).ToList();
        ListaMov.ItemsSource = Datos.Movimientos.OrderByDescending(m => m.Fecha).Take(60).ToList();
        int bajos = Datos.Ingredientes.Count(i => i.Activo && i.Bajo);
        decimal valor = Datos.Ingredientes.Where(i => i.Activo).Sum(i => (decimal)i.Existencia * i.CostoUnitario);
        TxtResumen.Text = $"{Datos.Ingredientes.Count(i => i.Activo)} ingredientes activos · {bajos} con stock bajo · Valor del inventario: {Fmt.Money(valor)}";
    }

    async void Exportar_Click(object sender, RoutedEventArgs e)
    {
        var ruta = Datos.Exportar("inventario", new { Fecha = DateTime.Now, Ingredientes = Datos.Ingredientes, Movimientos = Datos.Movimientos });
        if (await Dialogos.Confirmar(XamlRoot, "Inventario exportado", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }

    void Nuevo_Click(object sender, RoutedEventArgs e) => _ = Editar(null);
    void Editar_Click(object sender, RoutedEventArgs e) => _ = Editar((Ingrediente)((Button)sender).Tag);

    void Mover(Ingrediente ing, string tipo, double cant, string motivo)
    {
        Datos.Movimientos.Add(new MovimientoInventario
        {
            Id = Datos.Siguiente(Datos.Movimientos.Select(m => m.Id)), Fecha = DateTime.Now, IngredienteId = ing.Id, Ingrediente = ing.Nombre,
            Tipo = tipo, Cantidad = Math.Round(cant, 3), Unidad = ing.Unidad, Motivo = motivo, Usuario = Datos.Sesion.Nombre
        });
    }

    async Task Editar(Ingrediente ing)
    {
        bool nuevo = ing == null;
        var nombre = Campo.Texto("Nombre", ing?.Nombre);
        var unidad = new ComboBox { Header = "Unidad", HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var u in new[] { "kg", "g", "L", "ml", "pza" }) unidad.Items.Add(u);
        unidad.SelectedItem = ing?.Unidad ?? "kg";
        var existencia = Campo.Num(nuevo ? "Existencia inicial" : "Existencia actual (si la cambias se registra un ajuste)", ing?.Existencia ?? 0, false, 9);
        var minimo = Campo.Num("Stock mínimo (alerta)", ing?.Minimo, false, 9);
        var costo = Campo.Num("Costo unitario (MXN)", ing == null ? null : (double)ing.CostoUnitario, false, 8);
        var activo = new ToggleSwitch { Header = "Activo", IsOn = ing?.Activo ?? true };
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 380 };
        foreach (var c in new UIElement[] { nombre, unidad, existencia, minimo, costo, activo, err }) panel.Children.Add(c);

        var d = Dialogos.Nuevo(XamlRoot, nuevo ? "Nuevo ingrediente" : "Editar ingrediente", panel);
        Dialogos.Validar(d, err, () =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text)) return "El nombre es obligatorio.";
            if (Datos.Ingredientes.Any(i => i != ing && i.Nombre.Equals(nombre.Text.Trim(), StringComparison.OrdinalIgnoreCase))) return "Ya existe ese ingrediente.";
            string e;
            if ((e = Campo.NoNegativo(existencia, "Existencia", out _, 10000000)) != null) return e;
            if ((e = Campo.Positivo(minimo, "Stock mínimo", out _, 10000000)) != null) return e;
            if ((e = Campo.Positivo(costo, "Costo unitario", out _, 100000)) != null) return e;
            return null;
        }, () =>
        {
            double ex = Campo.Dbl(existencia);
            if (nuevo)
            {
                ing = new Ingrediente { Id = Datos.Siguiente(Datos.Ingredientes.Select(i => i.Id)) };
                Datos.Ingredientes.Add(ing);
                ing.Nombre = nombre.Text.Trim(); ing.Unidad = (string)unidad.SelectedItem; ing.Existencia = ex;
                if (ex > 0) Mover(ing, "Entrada", ex, "Existencia inicial");
            }
            else if (Math.Abs(ing.Existencia - ex) > 0.0001)
            {
                Mover(ing, "Ajuste", ex - ing.Existencia, $"Ajuste manual ({ing.Existencia:0.##} → {ex:0.##})");
                ing.Existencia = ex;
            }
            ing.Nombre = nombre.Text.Trim(); ing.Unidad = (string)unidad.SelectedItem;
            ing.Minimo = Campo.Dbl(minimo); ing.CostoUnitario = Campo.Dec(costo); ing.Activo = activo.IsOn;
            Datos.GuardarIngredientes(); Datos.GuardarMovimientos();
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Cargar();
        Notificador.Mostrar("Inventario actualizado.");
    }

    async void Entrada_Click(object sender, RoutedEventArgs e)
    {
        var combo = new ComboBox { Header = "Ingrediente", HorizontalAlignment = HorizontalAlignment.Stretch };
        var lista = Datos.Ingredientes.Where(i => i.Activo).OrderBy(i => i.Nombre).ToList();
        foreach (var i in lista) combo.Items.Add($"{i.Nombre} ({i.Unidad})");
        combo.SelectedIndex = lista.Count > 0 ? 0 : -1;
        var cant = Campo.Num("Cantidad recibida", null, false, 9);
        var costo = Campo.Num("Nuevo costo unitario en MXN (opcional)", null, false, 8);
        var nota = Campo.Texto("Proveedor / nota", "", "Ej. Carnicería El Norte");
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 380 };
        foreach (var c in new UIElement[] { combo, cant, costo, nota, err }) panel.Children.Add(c);
        var d = Dialogos.Nuevo(XamlRoot, "Registrar entrada", panel, "Registrar");
        Dialogos.Validar(d, err, () =>
        {
            if (combo.SelectedIndex < 0) return "Elige un ingrediente.";
            var m = Campo.Positivo(cant, "Cantidad recibida", out _, 10000000);
            if (m != null) return m;
            if (!string.IsNullOrWhiteSpace(costo.Text)) return Campo.Positivo(costo, "Costo unitario", out _, 100000);
            return null;
        }, () =>
        {
            var ing = lista[combo.SelectedIndex];
            var c = Campo.Dbl(cant);
            ing.Existencia = Math.Round(ing.Existencia + c, 3);
            if (Campo.Dec(costo) > 0) ing.CostoUnitario = Campo.Dec(costo);
            Mover(ing, "Entrada", c, string.IsNullOrWhiteSpace(nota.Text) ? "Compra" : nota.Text.Trim());
            Datos.GuardarIngredientes(); Datos.GuardarMovimientos();
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Cargar();
        Notificador.Mostrar("Entrada registrada.");
    }
}
