namespace AsaderoRegio;

public sealed partial class GuarnicionesPage : Page
{
    public GuarnicionesPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        TxtGuarniciones.Text = string.Join("\n", Datos.Config.Guarniciones);
        Anim.Enter(Content, 0, 16);
    }

    void Guardar_Click(object sender, RoutedEventArgs e)
    {
        var l = TxtGuarniciones.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        string err = null;
        if (l.Count < 3) err = "Se necesitan al menos 3 guarniciones distintas.";
        else if (l.Any(x => x.Length > 60)) err = "Cada guarnición debe tener máximo 60 caracteres.";
        TxtError.Text = err ?? "";
        TxtError.Visibility = err == null ? Visibility.Collapsed : Visibility.Visible;
        if (err != null) return;
        Datos.Config.Guarniciones = l;
        Datos.GuardarConfig();
        TxtGuarniciones.Text = string.Join("\n", l);
        Notificador.Mostrar("Guarniciones guardadas.");
    }
}
