namespace AsaderoRegio;

public sealed partial class AjustesPage : Page
{
    public AjustesPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        TxtRuta.Text = "Carpeta de trabajo: " + Datos.CarpetaRaiz + "\n(Datos · Exportaciones · Respaldos)";
        CmbRespaldos.ItemsSource = Datos.ListarRespaldos();
        Anim.Enter(Content, 0, 16);
    }

    async void Respaldo_Click(object sender, RoutedEventArgs e)
    {
        var ruta = Datos.Respaldar();
        CmbRespaldos.ItemsSource = Datos.ListarRespaldos();
        if (await Dialogos.Confirmar(XamlRoot, "Respaldo creado", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }

    async void ExportarTodo_Click(object sender, RoutedEventArgs e)
    {
        var ruta = Datos.ExportarTodo();
        if (await Dialogos.Confirmar(XamlRoot, "Exportación completa", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }

    void AbrirDatos_Click(object sender, RoutedEventArgs e) => Datos.AbrirCarpeta(Datos.CarpetaDatos);
    void AbrirExport_Click(object sender, RoutedEventArgs e) => Datos.AbrirCarpeta(Datos.CarpetaExport);

    async void Restaurar_Click(object sender, RoutedEventArgs e)
    {
        var sel = CmbRespaldos.SelectedItem as string;
        if (sel == null) { Notificador.Mostrar("Elige un respaldo.", false); return; }
        if (!await Dialogos.Confirmar(XamlRoot, "Restaurar respaldo", $"Se reemplazarán los datos actuales por el respaldo {sel}. ¿Continuar?", "Restaurar", "Cancelar")) return;
        try
        {
            Datos.Restaurar(sel);
            MainWindow.Actual.IrALogin();
        }
        catch (Exception ex) { Notificador.Mostrar("No se pudo restaurar: " + ex.Message, false); }
    }
}
