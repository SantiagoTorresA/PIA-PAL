namespace AsaderoRegio;

public sealed partial class AbiertosPage : Page
{
    readonly HashSet<object> _hover = new();

    public AbiertosPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e) => Cargar();

    void Cargar()
    {
        var lista = Datos.Cuentas.Where(c => c.Estado == "Abierta").OrderBy(c => c.FechaApertura).Select(Crear).ToList();
        Rejilla.ItemsSource = lista;
        TxtResumen.Text = lista.Count == 0 ? "No hay pedidos abiertos." : $"{lista.Count} pedido(s) abierto(s).";
    }

    static CuentaVM Crear(Cuenta c)
    {
        var est = c.EstadoMesero;
        var min = (int)(DateTime.Now - c.FechaApertura).TotalMinutes;
        return new CuentaVM
        {
            Cuenta = c, Titulo = c.Titulo, Fondo = c.ColorEstado,
            Emoji = est switch { "En preparación" => "🔥", "Listo para entregar" => "🛎", "Entregado" => "🍽", "Por cobrar" => "🧾", _ => "📝" },
            Linea1 = est,
            Linea2 = $"{c.ItemsActivos.Sum(i => i.Cantidad)} platillos · {Fmt.Money(c.Total)} · {min} min"
        };
    }

    void Rejilla_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs a)
    {
        if (a.InRecycleQueue || a.Phase != 0) return;
        Anim.Enter(a.ItemContainer, a.ItemIndex * 35, 18);
        if (_hover.Add(a.ItemContainer))
        {
            a.ItemContainer.PointerEntered += (o, _) => Anim.Scale((UIElement)o, 1.06);
            a.ItemContainer.PointerExited += (o, _) => Anim.Scale((UIElement)o, 1.0);
        }
    }

    async void Rejilla_ItemClick(object sender, ItemClickEventArgs e)
    {
        var c = ((CuentaVM)e.ClickedItem).Cuenta;
        bool abrirMenu = false, cerrarMesa = false;

        var panel = new StackPanel { Spacing = 8, MinWidth = 440 };
        panel.Children.Add(new TextBlock { Text = $"{c.Titulo} · {c.Folio}", FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = Paleta.Amarillo });
        panel.Children.Add(new TextBlock { Text = "Estado: " + c.EstadoMesero, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        foreach (var it in c.ItemsActivos)
            panel.Children.Add(new TextBlock { Text = $"{it.Cantidad} × {it.Descripcion}  —  {it.EstadoTexto}", TextWrapping = TextWrapping.Wrap });
        if (!c.ItemsActivos.Any()) panel.Children.Add(new TextBlock { Text = "Sin platillos todavía." });

        string ayuda = c.EstadoMesero switch
        {
            "Listo para entregar" => "Marca el pedido como entregado cuando lo lleves a la mesa.",
            "Entregado" => "El pedido ya fue entregado. Ahora puedes pasarlo a cobrar.",
            "Por cobrar" => "La cuenta está por cobrar. El cajero la cobrará.",
            "En preparación" => "El pedido sigue en preparación en cocina.",
            _ => "Envía los platillos a cocina desde el Menú."
        };
        panel.Children.Add(new TextBlock { Text = ayuda, TextWrapping = TextWrapping.Wrap, Foreground = Paleta.Naranja, Margin = new Thickness(0, 6, 0, 0) });

        var d = Dialogos.Nuevo(XamlRoot, "Pedido abierto", panel, "Marcar como entregado");
        d.SecondaryButtonText = "Pasar a por cobrar";
        d.CloseButtonText = "Cerrar";
        d.IsPrimaryButtonEnabled = c.PuedeEntregar;
        d.IsSecondaryButtonEnabled = c.PuedeCobrar;

        if (!c.SolicitoCuenta)
        {
            var link = new HyperlinkButton { Content = "Agregar productos desde el Menú" };
            link.Click += (_, _) => { abrirMenu = true; d.Hide(); };
            panel.Children.Add(link);
        }
        if (!c.ItemsActivos.Any() && c.Pagos.Count == 0)
        {
            var cerrar = new Button { Content = "Cerrar mesa (sin consumo)" };
            cerrar.Click += (_, _) => { cerrarMesa = true; d.Hide(); };
            panel.Children.Add(cerrar);
        }

        var r = await d.ShowAsync();
        if (r == ContentDialogResult.Primary) { Datos.MarcarEntregado(c); Notificador.Mostrar("Pedido marcado como entregado."); }
        else if (r == ContentDialogResult.Secondary) { Datos.PasarACobrar(c); Notificador.Mostrar("Pedido pasado a por cobrar."); }
        else if (abrirMenu) { ShellPage.Actual.IrA("menu", c); return; }
        else if (cerrarMesa)
        {
            if (Datos.CerrarMesaVacia(c)) Notificador.Mostrar($"Mesa {c.MesaNumero} cerrada.");
        }
        Cargar();
    }
}
