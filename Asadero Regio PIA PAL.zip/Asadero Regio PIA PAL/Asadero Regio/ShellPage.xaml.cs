namespace AsaderoRegio;

public sealed partial class ShellPage : Page
{
    public static ShellPage Actual { get; private set; }
    object _param;
    readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(3.5) };

    // tag, tipo de página, texto, roles con acceso, roles que la ven deshabilitada
    readonly List<(string tag, Type tipo, string texto, string[] roles, string[] bloqueado)> _paginas = new()
    {
        ("mesas", typeof(MesasPage), "🍽  Mesas", new[] { Roles.Admin, Roles.Cajero, Roles.Mesero, Roles.Cocina }, new string[0]),
        ("abiertos", typeof(AbiertosPage), "📋  Pedidos abiertos", new[] { Roles.Mesero }, new string[0]),
        ("menu", typeof(PedidosPage), "📝  Menú", new[] { Roles.Admin, Roles.Cajero, Roles.Mesero, Roles.Cocina }, new string[0]),
        ("cocina", typeof(CocinaPage), "🍳  Cocina", new[] { Roles.Cocina }, new string[0]),
        ("cuentas", typeof(CuentasPage), "💳  Cuentas y pagos", new[] { Roles.Admin, Roles.Cajero }, new string[0]),
        ("corte", typeof(CorteCajaPage), "🧮  Corte de caja", new[] { Roles.Admin, Roles.Cajero }, new string[0]),
        ("productos", typeof(ProductosPage), "🥩  Productos y precios", new[] { Roles.Admin }, new string[0]),
        ("inventario", typeof(InventarioPage), "📦  Inventario", new[] { Roles.Admin }, new string[0]),
        ("guarniciones", typeof(GuarnicionesPage), "🥗  Guarniciones", new[] { Roles.Admin }, new string[0]),
        ("reportes", typeof(ReportesPage), "📊  Reportes", new[] { Roles.Admin }, new string[0]),
        ("usuarios", typeof(UsuariosPage), "👥  Usuarios", new[] { Roles.Admin }, new string[0]),
        ("ajustes", typeof(AjustesPage), "⚙  Respaldo y ajustes", new[] { Roles.Admin }, new string[0]),
    };
    readonly Dictionary<string, NavigationViewItem> _items = new();

    public ShellPage()
    {
        InitializeComponent();
        Actual = this;
        _timer.Tick += (_, _) => { _timer.Stop(); Aviso.IsOpen = false; };
        var u = Datos.Sesion;
        TxtUsuarioNav.Text = u.Nombre;
        TxtRolNav.Text = u.Rol;
        foreach (var p in _paginas)
        {
            if (!p.roles.Contains(u.Rol)) continue;
            var item = new NavigationViewItem { Content = p.texto, Tag = p.tag, FontSize = 15, IsEnabled = !p.bloqueado.Contains(u.Rol) };
            _items[p.tag] = item;
            Nav.MenuItems.Add(item);
        }
        Loaded += (_, _) =>
        {
            Anim.Enter(Nav, 0, 0);
            Nav.SelectedItem = _items[u.Rol == Roles.Cocina ? "cocina" : "mesas"];
        };
    }

    public void IrA(string tag, object param = null)
    {
        if (!_items.TryGetValue(tag, out var item) || !item.IsEnabled) { Notificar("No tienes permiso para abrir esa sección.", false); return; }
        if (Nav.SelectedItem == item) { Navegar(tag, param); return; }
        _param = param;
        Nav.SelectedItem = item;
    }

    void Nav_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        if (args.SelectedItem is NavigationViewItem it)
        {
            var p = _param; _param = null;
            Navegar((string)it.Tag, p);
        }
    }

    void Navegar(string tag, object param)
    {
        Contenido.Navigate(_paginas.First(x => x.tag == tag).tipo, param, new EntranceNavigationTransitionInfo());
        Contenido.BackStack.Clear();
    }

    public void Notificar(string msg, bool ok = true)
    {
        Aviso.Severity = ok ? InfoBarSeverity.Success : InfoBarSeverity.Error;
        Aviso.Title = "";
        Aviso.Message = msg;
        Aviso.IsOpen = true;
        Anim.Enter(Aviso, 0, -18);
        _timer.Stop(); _timer.Start();
    }

    void Salir_Click(object sender, RoutedEventArgs e) => MainWindow.Actual.IrALogin();

    async void Password_Click(object sender, RoutedEventArgs e)
    {
        var actual = new PasswordBox { Header = "Contraseña actual" };
        var nueva = new PasswordBox { Header = "Nueva contraseña (mínimo 6 caracteres)" };
        var conf = new PasswordBox { Header = "Confirmar nueva contraseña" };
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 340 };
        panel.Children.Add(actual); panel.Children.Add(nueva); panel.Children.Add(conf); panel.Children.Add(err);
        var d = Dialogos.Nuevo(XamlRoot, "Cambiar mi contraseña", panel, "Cambiar");
        Dialogos.Validar(d, err, () =>
        {
            var u = Datos.Sesion;
            if (Datos.Hash(actual.Password, u.Salt) != u.PasswordHash) return "La contraseña actual no es correcta.";
            if (nueva.Password.Length < 6) return "La nueva contraseña debe tener al menos 6 caracteres.";
            if (nueva.Password != conf.Password) return "La confirmación no coincide.";
            return null;
        }, () =>
        {
            Datos.FijarPassword(Datos.Sesion, nueva.Password);
            Datos.GuardarUsuarios();
            Notificar("Contraseña actualizada.");
        });
        await d.ShowAsync();
    }
}
