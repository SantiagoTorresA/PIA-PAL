namespace AsaderoRegio;

public sealed partial class CorteCajaPage : Page
{
    public CorteCajaPage() { InitializeComponent(); Campo.SoloNumeros(TbFondo, false, 9); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        Refrescar();
        Anim.Enter(Tarjeta, 0);
        Anim.Enter(TarjetaHist, 130);
    }

    void Refrescar()
    {
        var c = Datos.CorteAbierto;
        var hist = Datos.Cortes.Where(x => x.Estado == "Cerrado");
        if (CdpDesde.Date.HasValue) { var d0 = CdpDesde.Date.Value.Date; hist = hist.Where(x => (x.FechaCierre ?? x.FechaApertura) >= d0); }
        if (CdpHasta.Date.HasValue) { var d1 = CdpHasta.Date.Value.Date.AddDays(1); hist = hist.Where(x => (x.FechaCierre ?? x.FechaApertura) < d1); }
        ListaCortes.ItemsSource = hist.OrderByDescending(x => x.FechaCierre).ToList();
        if (c == null)
        {
            PanelCerrada.Visibility = Visibility.Visible;
            PanelAbierta.Visibility = Visibility.Collapsed;
            return;
        }
        PanelCerrada.Visibility = Visibility.Collapsed;
        PanelAbierta.Visibility = Visibility.Visible;
        Datos.Resumir(c);
        TxtFolio.Text = $"{c.Folio} · Caja abierta";
        TxtApertura.Text = $"Abierta el {Fmt.Fecha(c.FechaApertura)} por {c.Usuario}";
        TxtFondo.Text = Fmt.Money(c.FondoInicial);
        TxtEfectivo.Text = Fmt.Money(c.VentasEfectivo);
        TxtTarjeta.Text = Fmt.Money(c.VentasTarjeta);
        TxtPropinas.Text = Fmt.Money(c.Propinas);
        TxtGastos.Text = "-" + Fmt.Money(c.Gastos);
        TxtTotalVentas.Text = Fmt.Money(c.TotalVentas);
        TxtNumCuentas.Text = $"{c.NumeroCuentas} cuentas cobradas · {Datos.Cuentas.Count(x => x.Estado == "Abierta")} cuentas abiertas";
        TxtEsperado.Text = Fmt.Money(c.EfectivoEsperado);
        ListaGastos.ItemsSource = Datos.Gastos.Where(g => g.CorteId == c.Id).OrderByDescending(g => g.Fecha).ToList();
    }

    void Abrir_Click(object sender, RoutedEventArgs e)
    {
        if (Datos.CorteAbierto != null) return;
        var errFondo = Campo.NoNegativo(TbFondo, "Fondo inicial", out _, 1000000);
        if (errFondo != null) { Notificador.Mostrar(errFondo, false); return; }
        var id = Datos.Siguiente(Datos.Cortes.Select(x => x.Id));
        Datos.Cortes.Add(new Corte
        {
            Id = id, Folio = $"Corte-{id}", FechaApertura = DateTime.Now, Usuario = Datos.Sesion.Nombre,
            FondoInicial = Campo.Dec(TbFondo), Estado = "Abierto"
        });
        Datos.GuardarCortes();
        Refrescar();
        Anim.Enter(Tarjeta, 0, 30);
        Notificador.Mostrar("Caja abierta. ¡Buen turno!");
    }

    async void Gasto_Click(object sender, RoutedEventArgs e)
    {
        var c = Datos.CorteAbierto;
        if (c == null) return;
        var concepto = Campo.Texto("Concepto", "", "Ej. Hielo, gas, retiro a caja fuerte…");
        var monto = Campo.Num("Monto (MXN)", null, false, 9);
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 340 };
        foreach (var x in new UIElement[] { concepto, monto, err }) panel.Children.Add(x);
        var d = Dialogos.Nuevo(XamlRoot, "Gasto / retiro de caja", panel, "Registrar");
        Dialogos.Validar(d, err, () =>
            string.IsNullOrWhiteSpace(concepto.Text) ? "Escribe el concepto." :
            Campo.Positivo(monto, "Monto", out _, 1000000), () =>
        {
            Datos.Gastos.Add(new Gasto
            {
                Id = Datos.Siguiente(Datos.Gastos.Select(g => g.Id)), Fecha = DateTime.Now, Concepto = concepto.Text.Trim(),
                Monto = Campo.Dec(monto), CorteId = c.Id, Usuario = Datos.Sesion.Nombre
            });
            Datos.GuardarGastos();
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Refrescar();
        Notificador.Mostrar("Gasto registrado.");
    }

    async void CerrarCaja_Click(object sender, RoutedEventArgs e)
    {
        var c = Datos.CorteAbierto;
        if (c == null) return;
        int abiertas = Datos.Cuentas.Count(x => x.Estado == "Abierta");
        if (abiertas > 0)
        {
            await Dialogos.Info(XamlRoot, "Hay cuentas abiertas", $"Hay {abiertas} cuenta(s) abiertas. Cóbralas o cancélalas antes de cerrar la caja.");
            return;
        }
        Datos.Resumir(c);
        var info = new TextBlock { Text = $"Efectivo esperado: {Fmt.Money(c.EfectivoEsperado)}", FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = Paleta.Amarillo };
        var contado = Campo.Num("Efectivo contado en caja (MXN)", (double)c.EfectivoEsperado, false, 10);
        var notas = Campo.Texto("Observaciones (opcional)");
        var panel = new StackPanel { Spacing = 10, MinWidth = 360 };
        foreach (var x in new UIElement[] { info, contado, notas }) panel.Children.Add(x);
        var errC = Dialogos.EtiquetaError();
        panel.Children.Add(errC);
        var d = Dialogos.Nuevo(XamlRoot, "Cerrar caja", panel, "Cerrar caja");
        Dialogos.Validar(d, errC, () => Campo.NoNegativo(contado, "Efectivo contado", out _, 100000000));
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;

        c.Estado = "Cerrado";
        c.FechaCierre = DateTime.Now;
        c.EfectivoContado = Campo.Dec(contado);
        c.Notas = notas.Text.Trim();
        Datos.Resumir(c);
        Datos.GuardarCortes();
        var ruta = Datos.Exportar("corte_" + c.Folio, new { Corte = c, Cuentas = Datos.Cuentas.Where(x => x.CorteId == c.Id), Gastos = Datos.Gastos.Where(g => g.CorteId == c.Id) });
        Datos.Respaldar();
        Refrescar();
        if (await Dialogos.Confirmar(XamlRoot, "Caja cerrada — " + c.DifTxt,
            $"Ventas: {Fmt.Money(c.TotalVentas)}\nEfectivo esperado: {Fmt.Money(c.EfectivoEsperado)}\nEfectivo contado: {Fmt.Money(c.EfectivoContado)}\n\nSe exportó el corte (JSON) y se creó un respaldo automático.\n{ruta}",
            "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }

    void Filtrar_Click(object sender, RoutedEventArgs e)
    {
        if (CdpDesde.Date.HasValue && CdpHasta.Date.HasValue && CdpDesde.Date.Value.Date > CdpHasta.Date.Value.Date)
        { Notificador.Mostrar("La fecha inicial no puede ser mayor a la final.", false); return; }
        Refrescar();
    }

    void Limpiar_Click(object sender, RoutedEventArgs e)
    {
        CdpDesde.Date = null; CdpHasta.Date = null;
        Refrescar();
    }

    async void ExportarTodos_Click(object sender, RoutedEventArgs e)
    {
        var l = (ListaCortes.ItemsSource as IEnumerable<Corte>)?.ToList() ?? new List<Corte>();
        if (l.Count == 0) { Notificador.Mostrar("No hay cortes en la lista para exportar.", false); return; }
        string etiqueta = CdpDesde.Date.HasValue || CdpHasta.Date.HasValue
            ? $"{(CdpDesde.Date.HasValue ? CdpDesde.Date.Value.ToString("yyyyMMdd") : "inicio")}_a_{(CdpHasta.Date.HasValue ? CdpHasta.Date.Value.ToString("yyyyMMdd") : "hoy")}"
            : "todos";
        var r = Datos.ExportarCortes(l, etiqueta);
        if (await Dialogos.Confirmar(XamlRoot, $"{l.Count} cortes exportados", "Se guardaron:\n" + string.Join("\n", r), "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(r[0]);
    }

    async void ExportarCorte_Click(object sender, RoutedEventArgs e)
    {
        var c = (Corte)((Button)sender).Tag;
        var ruta = Datos.Exportar("corte_" + c.Folio, new { Corte = c, Cuentas = Datos.Cuentas.Where(x => x.CorteId == c.Id), Gastos = Datos.Gastos.Where(g => g.CorteId == c.Id) });
        if (await Dialogos.Confirmar(XamlRoot, "Corte exportado", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }
}
