namespace AsaderoRegio;

public static class Fmt
{
    public static readonly CultureInfo MX = new("es-MX");
    public static string Money(decimal v) => v.ToString("C2", MX);
    public static string Fecha(DateTime d) => d.ToString("dd/MM/yyyy HH:mm", MX);
    public static string Dia(DateTime d) => d.ToString("dd MMM yyyy", MX);
}

public static class Paleta
{
    public static SolidColorBrush Hex(string h)
    {
        h = h.TrimStart('#');
        return new SolidColorBrush(ColorHelper.FromArgb(255,
            Convert.ToByte(h.Substring(0, 2), 16), Convert.ToByte(h.Substring(2, 2), 16), Convert.ToByte(h.Substring(4, 2), 16)));
    }
    public static readonly SolidColorBrush Verde = Hex("1E8E5A");
    public static readonly SolidColorBrush VerdeClaro = Hex("3DDC84");
    public static readonly SolidColorBrush Rojo = Hex("D9481F");
    public static readonly SolidColorBrush RojoClaro = Hex("FF6B5E");
    public static readonly SolidColorBrush Morado = Hex("7B4FD1");
    public static readonly SolidColorBrush Amarillo = Hex("FFC93C");
    public static readonly SolidColorBrush Naranja = Hex("FF7A1A");
    public static readonly SolidColorBrush Gris = Hex("5A4640");
    public static readonly SolidColorBrush Azul = Hex("1F77B4");
    public static readonly SolidColorBrush Teal = Hex("16817A");
    public static readonly SolidColorBrush GrisCalido = Hex("6B5B53");

    public static SolidColorBrush Categoria(string c) => c switch
    {
        "Carne Asada y Tacos" => Hex("C0392B"),
        "Parrilladas" => Hex("D35400"),
        "Guisados Regios" => Hex("A0522D"),
        "Entradas y Extras" => Hex("16817A"),
        "Otros Platillos" => Hex("6C4AB6"),
        "Bebidas" => Hex("1F77B4"),
        _ => Hex("5A4640")
    };
}

public static class Anim
{
    static TimeSpan Ms(double v) => TimeSpan.FromMilliseconds(v);

    public static CompositeTransform CT(UIElement el)
    {
        if (el.RenderTransform is CompositeTransform c) return c;
        var n = new CompositeTransform();
        el.RenderTransform = n;
        el.RenderTransformOrigin = new Windows.Foundation.Point(0.5, 0.5);
        return n;
    }

    static void Add(Storyboard sb, DependencyObject target, string prop, double? from, double to, double ms, double delay = 0)
    {
        var a = new DoubleAnimation { To = to, Duration = Ms(ms), BeginTime = Ms(delay), EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
        if (from.HasValue) a.From = from;
        Storyboard.SetTarget(a, target);
        Storyboard.SetTargetProperty(a, prop);
        sb.Children.Add(a);
    }

    /// <summary>Aparece con fundido y deslizamiento hacia arriba.</summary>
    public static void Enter(UIElement el, double delay = 0, double dy = 22)
    {
        var ct = CT(el);
        ct.TranslateY = dy;
        el.Opacity = 0;
        var sb = new Storyboard();
        Add(sb, el, "Opacity", 0, 1, 380, delay);
        Add(sb, ct, "TranslateY", dy, 0, 420, delay);
        sb.Begin();
    }

    public static void Scale(UIElement el, double to, double ms = 140)
    {
        var ct = CT(el);
        var sb = new Storyboard();
        Add(sb, ct, "ScaleX", null, to, ms);
        Add(sb, ct, "ScaleY", null, to, ms);
        sb.Begin();
    }

    /// <summary>Rebote rápido (feedback al agregar algo).</summary>
    public static void Pop(UIElement el)
    {
        var ct = CT(el);
        var sb = new Storyboard();
        foreach (var p in new[] { "ScaleX", "ScaleY" })
        {
            var a = new DoubleAnimationUsingKeyFrames();
            a.KeyFrames.Add(new EasingDoubleKeyFrame { KeyTime = Ms(0), Value = 1 });
            a.KeyFrames.Add(new EasingDoubleKeyFrame { KeyTime = Ms(110), Value = 1.12 });
            a.KeyFrames.Add(new EasingDoubleKeyFrame { KeyTime = Ms(260), Value = 1 });
            Storyboard.SetTarget(a, ct);
            Storyboard.SetTargetProperty(a, p);
            sb.Children.Add(a);
        }
        sb.Begin();
    }

    public static void Shake(UIElement el)
    {
        var ct = CT(el);
        var a = new DoubleAnimationUsingKeyFrames();
        double[] xs = { 0, -14, 14, -10, 10, -5, 5, 0 };
        for (int i = 0; i < xs.Length; i++)
            a.KeyFrames.Add(new LinearDoubleKeyFrame { KeyTime = Ms(i * 60), Value = xs[i] });
        Storyboard.SetTarget(a, ct);
        Storyboard.SetTargetProperty(a, "TranslateX");
        var sb = new Storyboard();
        sb.Children.Add(a);
        sb.Begin();
    }

    public static void Pulse(UIElement el, double max = 1.06, double ms = 1400)
    {
        var ct = CT(el);
        var sb = new Storyboard();
        foreach (var p in new[] { "ScaleX", "ScaleY" })
        {
            var a = new DoubleAnimation
            {
                From = 1, To = max, Duration = Ms(ms), AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever,
                EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
            };
            Storyboard.SetTarget(a, ct);
            Storyboard.SetTargetProperty(a, p);
            sb.Children.Add(a);
        }
        sb.Begin();
    }
}

public static class Dialogos
{
    public static async Task Info(XamlRoot r, string titulo, string msg)
    {
        var d = new ContentDialog
        {
            XamlRoot = r, Title = titulo, CloseButtonText = "Aceptar", DefaultButton = ContentDialogButton.Close,
            Content = new TextBlock { Text = msg, TextWrapping = TextWrapping.Wrap }
        };
        await d.ShowAsync();
    }

    public static async Task<bool> Confirmar(XamlRoot r, string titulo, string msg, string si = "Sí", string no = "Cancelar")
    {
        var d = new ContentDialog
        {
            XamlRoot = r, Title = titulo, PrimaryButtonText = si, CloseButtonText = no, DefaultButton = ContentDialogButton.Primary,
            Content = new TextBlock { Text = msg, TextWrapping = TextWrapping.Wrap }
        };
        return await d.ShowAsync() == ContentDialogResult.Primary;
    }

    public static ContentDialog Nuevo(XamlRoot r, string titulo, UIElement contenido, string ok = "Guardar")
    {
        return new ContentDialog
        {
            XamlRoot = r, Title = titulo, PrimaryButtonText = ok, CloseButtonText = "Cancelar", DefaultButton = ContentDialogButton.Primary,
            Content = new ScrollViewer { Content = contenido, MaxHeight = 560, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }
        };
    }

    public static TextBlock EtiquetaError() => new TextBlock { Foreground = Paleta.RojoClaro, TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };

    public static void Validar(ContentDialog d, TextBlock lbl, Func<string> validar, Action ok = null)
    {
        d.PrimaryButtonClick += (s, e) =>
        {
            var err = validar();
            if (err != null) { e.Cancel = true; lbl.Text = err; lbl.Visibility = Visibility.Visible; }
            else ok?.Invoke();
        };
    }
}

public static class Campo
{
    public static TextBox Texto(string h, string v = "", string ph = "", bool multi = false, double alto = 0, int maxLen = 120)
    {
        var t = new TextBox { Header = h, Text = v ?? "", PlaceholderText = ph, MaxLength = maxLen };
        if (multi) { t.AcceptsReturn = true; t.TextWrapping = TextWrapping.Wrap; t.MaxLength = 0; if (alto > 0) t.Height = alto; }
        return t;
    }

    /// <summary>Cuadro numérico: solo acepta dígitos (y un punto si no es entero). Sin flechas.</summary>
    public static TextBox Num(string h, double? v = null, bool entero = true, int maxLen = 8, string ph = "")
    {
        var t = new TextBox { Header = h, PlaceholderText = ph };
        SoloNumeros(t, entero, maxLen);
        if (v.HasValue) t.Text = entero ? ((long)v.Value).ToString() : v.Value.ToString("0.###", CultureInfo.InvariantCulture);
        return t;
    }

    public static void SoloNumeros(TextBox t, bool entero = true, int maxLen = 8)
    {
        t.Tag = entero ? "E" : "D";
        t.MaxLength = maxLen;
        t.BeforeTextChanging += (s, a) =>
        {
            bool ent = (string)s.Tag == "E";
            int puntos = 0;
            foreach (var ch in a.NewText)
            {
                if (ch >= '0' && ch <= '9') continue;
                if (!ent && ch == '.' && ++puntos == 1) continue;
                a.Cancel = true; return;
            }
        };
    }

    /// <summary>Valida el cuadro numérico. Devuelve el mensaje de error o null si es válido.</summary>
    public static string Validar(TextBox t, string nombre, double min, double max, bool minIncluido, out double v)
    {
        v = 0;
        var s = (t.Text ?? "").Trim();
        if (s.Length == 0) return $"{nombre}: no puede quedar vacío.";
        if (!double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return $"{nombre}: captura solo números.";
        if (minIncluido ? v < min : v <= min)
            return minIncluido ? $"{nombre}: debe ser {min:0.##} o mayor." : $"{nombre}: debe ser mayor a {min:0.##}.";
        if (v > max) return $"{nombre}: el máximo permitido es {max:0.##}.";
        return null;
    }

    public static string Positivo(TextBox t, string nombre, out double v, double max = 10000000) => Validar(t, nombre, 0, max, false, out v);
    public static string NoNegativo(TextBox t, string nombre, out double v, double max = 10000000) => Validar(t, nombre, 0, max, true, out v);

    public static double Dbl(TextBox t) =>
        double.TryParse((t.Text ?? "").Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : 0;
    public static decimal Dec(TextBox t) => (decimal)Math.Round(Dbl(t), 2);
}

public static class Notificador
{
    public static void Mostrar(string msg, bool ok = true) => ShellPage.Actual?.Notificar(msg, ok);
}
