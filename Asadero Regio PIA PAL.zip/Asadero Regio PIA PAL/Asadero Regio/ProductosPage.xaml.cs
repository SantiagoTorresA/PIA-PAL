namespace AsaderoRegio;

public sealed partial class ProductosPage : Page
{
    bool _cargando;

    public ProductosPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        _cargando = true;
        CmbCategoria.Items.Clear();
        CmbCategoria.Items.Add("Todas");
        foreach (var c in Datos.Productos.Select(p => p.Categoria).Distinct().OrderBy(x => x)) CmbCategoria.Items.Add(c);
        CmbCategoria.SelectedIndex = 0;
        _cargando = false;
        Cargar();
        Anim.Enter(Lista, 80);
    }

    void Buscar_Changed(object sender, TextChangedEventArgs e) { if (!_cargando) Cargar(); }
    void Cat_Changed(object sender, SelectionChangedEventArgs e) { if (!_cargando) Cargar(); }

    void Cargar()
    {
        var cat = CmbCategoria.SelectedItem as string;
        var txt = (TxtBuscar.Text ?? "").Trim();
        var q = Datos.Productos.AsEnumerable();
        if (!string.IsNullOrEmpty(cat) && cat != "Todas") q = q.Where(p => p.Categoria == cat);
        if (txt.Length > 0) q = q.Where(p => p.Nombre.Contains(txt, StringComparison.OrdinalIgnoreCase));
        Lista.ItemsSource = q.OrderBy(p => p.Categoria).ThenBy(p => p.Nombre).ToList();
    }

    async void Exportar_Click(object sender, RoutedEventArgs e)
    {
        var ruta = Datos.Exportar("catalogo_productos", Datos.Productos);
        if (await Dialogos.Confirmar(XamlRoot, "Catálogo exportado", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }

    void Nuevo_Click(object sender, RoutedEventArgs e) => _ = Editar(null);
    void Editar_Click(object sender, RoutedEventArgs e) => _ = Editar((Producto)((Button)sender).Tag);

    async Task Editar(Producto p)
    {
        bool nuevo = p == null;
        var nombre = Campo.Texto("Nombre", p?.Nombre);
        var cat = new ComboBox { Header = "Categoría (puedes escribir una nueva)", IsEditable = true, HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var c in Datos.Productos.Select(x => x.Categoria).Distinct().OrderBy(x => x)) cat.Items.Add(c);
        cat.Text = p?.Categoria ?? "";
        var emoji = Campo.Texto("Icono (emoji que se muestra en el menú)", p?.Emoji ?? "", "", false, 0, 8);
        var desc = Campo.Texto("Descripción (opcional)", p?.Descripcion, "", false, 0, 200);
        var precio = Campo.Num("Precio de venta (MXN) — si el producto tiene opciones, el precio es el de cada opción", p == null ? null : (double)(p.Opciones.Count > 0 ? p.Opciones[0].Precio : p.Precio), false, 8);
        var guarn = Campo.Num("Guarniciones a elegir (0 si no lleva)", p?.Guarniciones ?? 0, true, 1);
        var activo = new ToggleSwitch { Header = "Disponible en el menú", IsOn = p?.Activo ?? true };

        // Opciones (opcional): una fila por opción con nombre, precio, interruptor "Activa" y botón de quitar
        var filasOp = new List<(StackPanel fila, TextBox nombre, TextBox precio, ToggleSwitch activa)>();
        var opPanel = new StackPanel { Spacing = 6 };
        void AgregarFila(Opcion o)
        {
            var tNom = Campo.Texto(null, o?.Nombre ?? "", "Nombre (ej. 2 personas)", false, 0, 40); tNom.Width = 190;
            var tPre = Campo.Num(null, o == null ? null : (double)o.Precio, false, 8, "Precio"); tPre.Width = 90;
            var act = new ToggleSwitch { IsOn = o?.Activo ?? true, OnContent = "Activa", OffContent = "Desactivada", MinWidth = 0, Width = 118 };
            var quitar = new Button { Content = "✖", VerticalAlignment = VerticalAlignment.Center };
            ToolTipService.SetToolTip(quitar, "Quitar esta opción");
            var fila = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            fila.Children.Add(tNom); fila.Children.Add(tPre); fila.Children.Add(act); fila.Children.Add(quitar);
            var reg = (fila, tNom, tPre, act);
            quitar.Click += (_, _) => { opPanel.Children.Remove(fila); filasOp.Remove(reg); };
            filasOp.Add(reg); opPanel.Children.Add(fila);
        }
        if (p != null) foreach (var o in p.Opciones) AgregarFila(o);
        var btnOpcion = new Button { Content = "＋ Agregar opción" };
        btnOpcion.Click += (_, _) => AgregarFila(null);
        var opTitulo = new TextBlock
        {
            Text = "Opciones (opcional): ej. sabores o tamaños. Usa el interruptor para desactivar una sola opción sin ocultar todo el platillo.",
            TextWrapping = TextWrapping.Wrap, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, Foreground = Paleta.Amarillo
        };

        // Receta: se marcan TODOS los ingredientes que lleva el platillo y su cantidad por porción
        var filas = new List<(Ingrediente ing, CheckBox chk, TextBox qty)>();
        var recetaPanel = new StackPanel { Spacing = 2 };
        foreach (var ing in Datos.Ingredientes.Where(i => i.Activo || (p?.Receta.Any(r => r.IngredienteId == i.Id) ?? false)).OrderBy(i => i.Nombre))
        {
            var existente = p?.Receta.FirstOrDefault(r => r.IngredienteId == ing.Id);
            var chk = new CheckBox { Content = $"{ing.Nombre} ({ing.Unidad})", MinWidth = 270, IsChecked = existente != null };
            var q = Campo.Num(null, existente?.Cantidad, false, 7, "cantidad");
            q.Width = 110; q.IsEnabled = existente != null;
            chk.Checked += (_, _) => q.IsEnabled = true;
            chk.Unchecked += (_, _) => q.IsEnabled = false;
            var fila = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            fila.Children.Add(chk); fila.Children.Add(q);
            recetaPanel.Children.Add(fila);
            filas.Add((ing, chk, q));
        }
        var recetaScroll = new ScrollViewer { Content = recetaPanel, MaxHeight = 230, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var recetaTitulo = new TextBlock
        {
            Text = "Receta para inventario: marca todos los ingredientes que lleva una porción e indica la cantidad",
            TextWrapping = TextWrapping.Wrap, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, Foreground = Paleta.Amarillo
        };
        var hist = new TextBlock { TextWrapping = TextWrapping.Wrap, FontSize = 12, Style = (Style)Application.Current.Resources["EstiloSuave"] };
        if (p != null && p.HistorialPrecios.Count > 0)
            hist.Text = "Historial de precios: " + string.Join(" · ", p.HistorialPrecios.TakeLast(4).Select(h => $"{h.Fecha:dd/MM/yy} {Fmt.Money(h.Anterior)}→{Fmt.Money(h.Nuevo)}"));
        var err = Dialogos.EtiquetaError();

        var panel = new StackPanel { Spacing = 10, MinWidth = 480 };
        foreach (var c in new UIElement[] { nombre, cat, emoji, desc, precio, guarn, activo, opTitulo, opPanel, btnOpcion, recetaTitulo, recetaScroll, hist, err }) panel.Children.Add(c);

        List<Opcion> ops = null; List<RecetaItem> rec = null; decimal pr = 0, co = 0; int g = 0;
        var d = Dialogos.Nuevo(XamlRoot, nuevo ? "Nuevo producto" : "Editar producto", panel);
        Dialogos.Validar(d, err, () =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text)) return "El nombre es obligatorio.";
            if (string.IsNullOrWhiteSpace(cat.Text)) return "La categoría es obligatoria.";
            if (Datos.Productos.Any(x => x != p && x.Nombre.Equals(nombre.Text.Trim(), StringComparison.OrdinalIgnoreCase))) return "Ya existe un producto con ese nombre.";

            ops = new List<Opcion>();
            string e;
            var usadas = filasOp.Where(f => !string.IsNullOrWhiteSpace(f.nombre.Text) || !string.IsNullOrWhiteSpace(f.precio.Text)).ToList();
            if (usadas.Count == 0)
            {
                if ((e = Campo.Positivo(precio, "Precio de venta", out var vp, 100000)) != null) return e;
                pr = (decimal)vp;
            }
            else
            {
                foreach (var f in usadas)
                {
                    var nom = f.nombre.Text.Trim();
                    if (nom.Length == 0) return "Hay una opción sin nombre.";
                    if (ops.Any(x => x.Nombre.Equals(nom, StringComparison.OrdinalIgnoreCase))) return $"La opción \"{nom}\" está repetida.";
                    if ((e = Campo.Positivo(f.precio, $"Precio de \"{nom}\"", out var op, 100000)) != null) return e;
                    ops.Add(new Opcion { Nombre = nom, Precio = (decimal)op, Activo = f.activa.IsOn });
                }
                pr = ops[0].Precio;
            }
            // El costo se calcula solo a partir de la receta (ingredientes); el factor de inventario según el precio de cada opción
            co = p?.Costo ?? 0;
            foreach (var o in ops) o.Factor = pr > 0 ? (double)(o.Precio / pr) : 1;

            if ((e = Campo.NoNegativo(guarn, "Guarniciones", out var vg, 5)) != null) return e;
            g = (int)vg;

            rec = new List<RecetaItem>();
            foreach (var (ing, chk, qty) in filas)
            {
                if (chk.IsChecked != true) continue;
                if ((e = Campo.Positivo(qty, $"Cantidad de {ing.Nombre}", out var vq, 100000)) != null) return e;
                rec.Add(new RecetaItem { IngredienteId = ing.Id, Cantidad = vq });
            }
            var costoRec = rec.Sum(r => (Datos.Ingredientes.FirstOrDefault(i => i.Id == r.IngredienteId)?.CostoUnitario ?? 0) * (decimal)r.Cantidad);
            if (costoRec > 0) co = Math.Round(costoRec, 2);
            foreach (var o in ops) o.Costo = Math.Round(co * (decimal)o.Factor, 2);
            return null;
        }, () =>
        {
            if (nuevo)
            {
                p = new Producto { Id = Datos.Siguiente(Datos.Productos.Select(x => x.Id)) };
                Datos.Productos.Add(p);
            }
            else if (p.Precio != pr)
                p.HistorialPrecios.Add(new CambioPrecio { Fecha = DateTime.Now, Anterior = p.Precio, Nuevo = pr, Usuario = Datos.Sesion.Nombre });
            p.Nombre = nombre.Text.Trim(); p.Categoria = cat.Text.Trim(); p.Emoji = string.IsNullOrWhiteSpace(emoji.Text) ? "🍽" : emoji.Text.Trim();
            p.Descripcion = desc.Text.Trim(); p.Precio = pr; p.Costo = co; p.Guarniciones = g;
            p.Activo = activo.IsOn; p.Opciones = ops; p.Receta = rec;
            Datos.GuardarProductos();
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        OnNavigatedTo(null);
        Notificador.Mostrar(nuevo ? "Producto creado." : "Producto actualizado.");
    }
}
