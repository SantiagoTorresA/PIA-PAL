using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace AsaderoRegio;

/// <summary>Capa de datos: todo se guarda en archivos JSON dentro de Documentos\AsaderoRegio.</summary>
public static class Datos
{
    public static readonly string CarpetaRaiz = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AsaderoRegio");
    public static string CarpetaDatos => Path.Combine(CarpetaRaiz, "Datos");
    public static string CarpetaExport => Path.Combine(CarpetaRaiz, "Exportaciones");
    public static string CarpetaRespaldos => Path.Combine(CarpetaRaiz, "Respaldos");

    public static List<Usuario> Usuarios = new();
    public static List<Producto> Productos = new();
    public static List<Ingrediente> Ingredientes = new();
    public static List<MovimientoInventario> Movimientos = new();
    public static List<Mesa> Mesas = new();
    public static List<Cuenta> Cuentas = new();
    public static List<Corte> Cortes = new();
    public static List<Gasto> Gastos = new();
    public static Configuracion Config = new();
    public static Usuario Sesion;

    static readonly JsonSerializerOptions Opc = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    // ───────────── Carga / guardado ─────────────
    public static void Iniciar()
    {
        Directory.CreateDirectory(CarpetaDatos);
        Directory.CreateDirectory(CarpetaExport);
        Directory.CreateDirectory(CarpetaRespaldos);

        Usuarios = Cargar("usuarios.json", () => new List<Usuario>());
        Productos = Cargar("productos.json", () => new List<Producto>());
        Ingredientes = Cargar("ingredientes.json", () => new List<Ingrediente>());
        Movimientos = Cargar("movimientos_inventario.json", () => new List<MovimientoInventario>());
        Mesas = Cargar("mesas.json", () => new List<Mesa>());
        Cuentas = Cargar("cuentas.json", () => new List<Cuenta>());
        Cortes = Cargar("cortes.json", () => new List<Corte>());
        Gastos = Cargar("gastos.json", () => new List<Gasto>());
        Config = Cargar("configuracion.json", () => new Configuracion());

        bool nuevoMenu = false;
        if (Config.Guarniciones.Count == 0)
        {
            Config.Guarniciones = new List<string>
            {
                "Frijoles refritos con veneno", "Arroz rojo", "Nopalitos asados", "Puré de papa casero",
                "Ensalada fresca", "Frijoles charros regios", "Tortillas de harina o maíz recién hechas"
            };
            GuardarConfig();
        }
        if (Usuarios.Count == 0) SembrarUsuarios();
        if (Mesas.Count == 0) SembrarMesas();
        if (Ingredientes.Count == 0) SembrarIngredientes();
        if (Productos.Count == 0) { SembrarMenu(); nuevoMenu = true; }
        if (nuevoMenu) GuardarProductos();
        Migrar();
    }

    static T Cargar<T>(string archivo, Func<T> porDefecto) where T : class
    {
        var ruta = Path.Combine(CarpetaDatos, archivo);
        if (!File.Exists(ruta)) return porDefecto();
        try { return JsonSerializer.Deserialize<T>(File.ReadAllText(ruta), Opc) ?? porDefecto(); }
        catch
        {
            try { File.Copy(ruta, ruta + ".corrupto_" + DateTime.Now.ToString("yyyyMMddHHmmss")); } catch { }
            return porDefecto();
        }
    }

    static void Guardar(string archivo, object datos)
    {
        Directory.CreateDirectory(CarpetaDatos);
        var ruta = Path.Combine(CarpetaDatos, archivo);
        var tmp = ruta + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(datos, datos.GetType(), Opc), Encoding.UTF8);
        File.Move(tmp, ruta, true);
    }

    public static void GuardarUsuarios() => Guardar("usuarios.json", Usuarios);
    public static void GuardarProductos() => Guardar("productos.json", Productos);
    public static void GuardarIngredientes() => Guardar("ingredientes.json", Ingredientes);
    public static void GuardarMovimientos() => Guardar("movimientos_inventario.json", Movimientos);
    public static void GuardarMesas() => Guardar("mesas.json", Mesas);
    public static void GuardarCuentas() => Guardar("cuentas.json", Cuentas);
    public static void GuardarCortes() => Guardar("cortes.json", Cortes);
    public static void GuardarGastos() => Guardar("gastos.json", Gastos);
    public static void GuardarConfig() => Guardar("configuracion.json", Config);

    public static int Siguiente(IEnumerable<int> ids) => (ids.Any() ? ids.Max() : 0) + 1;

    // ───────────── Exportación / respaldo ─────────────
    public static string Exportar(string nombre, object datos)
    {
        // Todas las exportaciones del mismo día se guardan en una carpeta con la fecha (aaaa-mm-dd).
        var dir = Path.Combine(CarpetaExport, DateTime.Now.ToString("yyyy-MM-dd"));
        Directory.CreateDirectory(dir);
        var baseNombre = $"{nombre}_{DateTime.Now:HHmmss}";
        var ruta = Path.Combine(dir, baseNombre + ".json");
        int n = 1;
        while (File.Exists(ruta)) ruta = Path.Combine(dir, $"{baseNombre}_{n++}.json");
        File.WriteAllText(ruta, JsonSerializer.Serialize(datos, datos.GetType(), Opc), Encoding.UTF8);
        return ruta;
    }

    static string Csv(string v) => "\"" + (v ?? "").Replace("\"", "\"\"") + "\"";

    /// <summary>CSV (abre directo en Excel). Se guarda junto a las demás exportaciones del día.</summary>
    public static string ExportarCsv(string nombre, string[] cabecera, IEnumerable<string[]> filas)
    {
        var dir = Path.Combine(CarpetaExport, DateTime.Now.ToString("yyyy-MM-dd"));
        Directory.CreateDirectory(dir);
        var baseNombre = $"{nombre}_{DateTime.Now:HHmmss}";
        var ruta = Path.Combine(dir, baseNombre + ".csv");
        int n = 1;
        while (File.Exists(ruta)) ruta = Path.Combine(dir, $"{baseNombre}_{n++}.csv");
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(",", cabecera.Select(Csv)));
        foreach (var f in filas) sb.AppendLine(string.Join(",", f.Select(Csv)));
        File.WriteAllText(ruta, sb.ToString(), new UTF8Encoding(true));
        return ruta;
    }

    public static string[] ExportarCuentas(IList<Cuenta> cuentas, string etiqueta)
    {
        var json = Exportar("cuentas_" + etiqueta, new { FechaExportacion = DateTime.Now, Total = cuentas.Count, Cuentas = cuentas });
        var csv = ExportarCsv("cuentas_" + etiqueta,
            new[] { "Folio", "Mesa", "Estado", "Apertura", "Cierre", "Mesero", "Cajero", "Personas", "Subtotal", "Descuento", "Propina", "Total", "Pagado", "Metodos de pago", "Motivo de cancelacion" },
            cuentas.Select(c => new[]
            {
                c.Folio, c.Titulo, c.Estado, Fmt.Fecha(c.FechaApertura), c.FechaCierre.HasValue ? Fmt.Fecha(c.FechaCierre.Value) : "",
                c.Mesero, c.Cajero, c.Personas.ToString(), c.Subtotal.ToString("0.00"), c.Descuento.ToString("0.00"), c.Propina.ToString("0.00"),
                c.Total.ToString("0.00"), c.Pagado.ToString("0.00"), string.Join(" / ", c.Pagos.Select(p => $"{p.Metodo} {p.Monto:0.00}")), c.MotivoCancelacion
            }));
        return new[] { json, csv };
    }

    public static string[] ExportarCortes(IList<Corte> cortes, string etiqueta)
    {
        foreach (var c in cortes) Resumir(c);
        var json = Exportar("cortes_" + etiqueta, new
        {
            FechaExportacion = DateTime.Now, Total = cortes.Count,
            Cortes = cortes.Select(c => new { Corte = c, Cuentas = Cuentas.Where(x => x.CorteId == c.Id), Gastos = Gastos.Where(g => g.CorteId == c.Id) })
        });
        var csv = ExportarCsv("cortes_" + etiqueta,
            new[] { "Folio", "Apertura", "Cierre", "Usuario", "Estado", "Fondo inicial", "Ventas efectivo", "Ventas tarjeta", "Ventas transferencia", "Propinas", "Gastos", "Total ventas", "Cuentas", "Efectivo esperado", "Efectivo contado", "Diferencia", "Notas" },
            cortes.Select(c => new[]
            {
                c.Folio, Fmt.Fecha(c.FechaApertura), c.FechaCierre.HasValue ? Fmt.Fecha(c.FechaCierre.Value) : "", c.Usuario, c.Estado,
                c.FondoInicial.ToString("0.00"), c.VentasEfectivo.ToString("0.00"), c.VentasTarjeta.ToString("0.00"), c.VentasTransferencia.ToString("0.00"),
                c.Propinas.ToString("0.00"), c.Gastos.ToString("0.00"), c.TotalVentas.ToString("0.00"), c.NumeroCuentas.ToString(),
                c.EfectivoEsperado.ToString("0.00"), c.EfectivoContado.ToString("0.00"), c.Diferencia.ToString("0.00"), c.Notas
            }));
        return new[] { json, csv };
    }

    public static string ExportarTodo()
    {
        return Exportar("exportacion_completa", new
        {
            FechaExportacion = DateTime.Now,
            Config,
            Usuarios = Usuarios.Select(u => new { u.Id, u.Nombre, u.NombreUsuario, u.Rol, u.Activo, u.FechaAlta }),
            Productos, Ingredientes, Movimientos, Mesas, Cuentas, Cortes, Gastos
        });
    }

    public static string Respaldar()
    {
        var destino = Path.Combine(CarpetaRespaldos, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(destino);
        foreach (var f in Directory.GetFiles(CarpetaDatos, "*.json"))
            File.Copy(f, Path.Combine(destino, Path.GetFileName(f)), true);
        return destino;
    }

    public static List<string> ListarRespaldos() =>
        Directory.Exists(CarpetaRespaldos)
            ? Directory.GetDirectories(CarpetaRespaldos).Select(Path.GetFileName).OrderByDescending(x => x).ToList()
            : new List<string>();

    public static void Restaurar(string nombreRespaldo)
    {
        Respaldar(); // respaldo de seguridad del estado actual
        var origen = Path.Combine(CarpetaRespaldos, nombreRespaldo);
        foreach (var f in Directory.GetFiles(origen, "*.json"))
            File.Copy(f, Path.Combine(CarpetaDatos, Path.GetFileName(f)), true);
        Iniciar();
    }

    public static void AbrirCarpeta(string ruta)
    {
        try
        {
            if (File.Exists(ruta)) Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{ruta}\"") { UseShellExecute = true });
            else Process.Start(new ProcessStartInfo("explorer.exe", $"\"{ruta}\"") { UseShellExecute = true });
        }
        catch { }
    }

    // ───────────── Autenticación ─────────────
    public static string Hash(string pass, string salt)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(salt + pass)));
    }

    public static Usuario Login(string usuario, string pass)
    {
        var u = Usuarios.FirstOrDefault(x => x.Activo && x.NombreUsuario.Equals((usuario ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
        if (u == null) return null;
        return Hash(pass ?? "", u.Salt) == u.PasswordHash ? u : null;
    }

    public static void FijarPassword(Usuario u, string pass)
    {
        u.Salt = Guid.NewGuid().ToString("N");
        u.PasswordHash = Hash(pass, u.Salt);
    }

    static void SembrarUsuarios()
    {
        void U(string nombre, string user, string pass, string rol)
        {
            var u = new Usuario { Id = Usuarios.Count + 1, Nombre = nombre, NombreUsuario = user, Rol = rol };
            FijarPassword(u, pass);
            Usuarios.Add(u);
        }
        U("Administrador General", "admin", "admin123", Roles.Admin);
        U("Cajero Turno", "cajero", "cajero123", Roles.Cajero);
        U("Mesero Turno", "mesero", "mesero123", Roles.Mesero);
        GuardarUsuarios();
    }

    // ───────────── Mesas / cuentas ─────────────
    static void SembrarMesas()
    {
        int[] caps = { 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 8, 10 };
        for (int i = 0; i < caps.Length; i++) Mesas.Add(new Mesa { Id = i + 1, Numero = i + 1, Capacidad = caps[i] });
        GuardarMesas();
    }

    public static Cuenta CuentaAbiertaDeMesa(int mesaId) => Cuentas.FirstOrDefault(c => c.Estado == "Abierta" && c.MesaId == mesaId && mesaId != 0);

    public static Cuenta NuevaCuenta(Mesa mesa, int personas)
    {
        var c = new Cuenta
        {
            Id = Siguiente(Cuentas.Select(x => x.Id)),
            MesaId = mesa?.Id ?? 0,
            MesaNumero = mesa?.Numero ?? 0,
            Personas = personas,
            Mesero = Sesion?.Nombre ?? "",
            FechaApertura = DateTime.Now
        };
        c.Folio = $"C-{c.Id}";
        Cuentas.Add(c);
        GuardarCuentas();
        return c;
    }

    public static ItemPedido AgregarItem(Cuenta c, Producto p, Opcion o, List<string> guarn, int cant, string notas)
    {
        guarn ??= new List<string>();
        notas ??= "";
        var ex = c.Items.FirstOrDefault(i => !i.Cancelado && !i.Enviado && i.ProductoId == p.Id && i.Opcion == (o?.Nombre ?? "")
            && i.Notas == notas && i.Guarniciones.OrderBy(x => x).SequenceEqual(guarn.OrderBy(x => x)));
        if (ex != null) { ex.Cantidad += cant; return ex; }
        double factor = o?.Factor ?? 1;
        var costoReceta = p.CostoReceta;
        var costo = costoReceta > 0 ? Math.Round(costoReceta * (decimal)factor, 2) : (o?.Costo ?? p.Costo);
        var it = new ItemPedido
        {
            Id = Siguiente(c.Items.Select(i => i.Id)),
            ProductoId = p.Id, Nombre = p.Nombre, Categoria = p.Categoria, Emoji = p.Emoji,
            Opcion = o?.Nombre ?? "", Guarniciones = new List<string>(guarn), Cantidad = cant,
            PrecioUnitario = o?.Precio ?? p.Precio, CostoUnitario = costo,
            Factor = o?.Factor ?? 1, Notas = notas
        };
        c.Items.Add(it);
        return it;
    }

    public static Corte CorteAbierto => Cortes.FirstOrDefault(c => c.Estado == "Abierto");

    public static void CerrarCuenta(Cuenta c)
    {
        c.Estado = "Pagada";
        c.FechaCierre = DateTime.Now;
        c.CorteId = CorteAbierto?.Id ?? 0;
        c.Cajero = Sesion?.Nombre ?? "";
        GuardarCuentas();
    }

    // ───────────── Flujo de cocina y servicio ─────────────
    public static bool CerrarMesaVacia(Cuenta c)
    {
        if (c.ItemsActivos.Any() || c.Pagos.Count > 0) return false;
        c.Estado = "Cancelada";
        c.FechaCierre = DateTime.Now;
        c.MotivoCancelacion = "Mesa cerrada sin consumo";
        GuardarCuentas();
        return true;
    }

    public static void CancelarCuenta(Cuenta c, string motivo)
    {
        var uso = new Dictionary<int, double>();
        foreach (var it in c.ItemsActivos.Where(i => i.Enviado)) Sumar(uso, it.ProductoId, it.Factor * it.Cantidad);
        Devolver(uso, $"Cancelación {c.Folio}");
        c.Estado = "Cancelada";
        c.FechaCierre = DateTime.Now;
        c.MotivoCancelacion = motivo;
        GuardarCuentas();
    }

    /// <summary>Envía lo pendiente a cocina y descuenta los ingredientes del inventario.</summary>
    public static int EnviarACocina(Cuenta c)
    {
        var nuevos = c.ItemsActivos.Where(i => !i.Enviado).ToList();
        if (nuevos.Count == 0) return 0;
        var uso = new Dictionary<int, double>();
        foreach (var it in nuevos)
        {
            Sumar(uso, it.ProductoId, it.Factor * it.Cantidad);
            it.Enviado = true; it.EstadoCocina = "Preparando"; it.FechaEnvio = DateTime.Now;
        }
        Descontar(uso, $"Pedido {c.Folio}");
        GuardarCuentas();
        return nuevos.Sum(i => i.Cantidad);
    }

    public static void MarcarListo(Cuenta c)
    {
        foreach (var it in c.ItemsActivos.Where(i => i.EstadoCocina == "Preparando")) it.EstadoCocina = "Listo";
        GuardarCuentas();
    }

    public static void MarcarEntregado(Cuenta c)
    {
        foreach (var it in c.ItemsActivos.Where(i => i.EstadoCocina == "Listo")) it.EstadoCocina = "Entregado";
        GuardarCuentas();
    }

    public static void PasarACobrar(Cuenta c)
    {
        c.SolicitoCuenta = true;
        GuardarCuentas();
    }

    /// <summary>Cancela n unidades de un renglón. Si ya se envió a cocina, regresa los ingredientes al inventario.</summary>
    public static void CancelarUnidades(Cuenta c, ItemPedido it, int n)
    {
        n = Math.Min(n, it.Cantidad);
        if (n <= 0) return;
        if (it.Enviado)
        {
            var uso = new Dictionary<int, double>();
            Sumar(uso, it.ProductoId, it.Factor * n);
            Devolver(uso, $"Cancelación {c.Folio}");
        }
        if (n >= it.Cantidad) it.Cancelado = true; else it.Cantidad -= n;
        GuardarCuentas();
    }

    static void Sumar(Dictionary<int, double> d, int productoId, double mult)
    {
        var p = Productos.FirstOrDefault(x => x.Id == productoId);
        if (p == null) return;
        foreach (var r in p.Receta) d[r.IngredienteId] = d.GetValueOrDefault(r.IngredienteId) + r.Cantidad * mult;
    }

    static void Mover(Dictionary<int, double> uso, string tipo, string motivo)
    {
        foreach (var kv in uso)
        {
            var ing = Ingredientes.FirstOrDefault(i => i.Id == kv.Key);
            if (ing == null) continue;
            ing.Existencia = tipo == "Salida" ? Math.Max(0, Math.Round(ing.Existencia - kv.Value, 3)) : Math.Round(ing.Existencia + kv.Value, 3);
            Movimientos.Add(new MovimientoInventario
            {
                Id = Siguiente(Movimientos.Select(m => m.Id)), Fecha = DateTime.Now, IngredienteId = ing.Id, Ingrediente = ing.Nombre,
                Tipo = tipo, Cantidad = Math.Round(kv.Value, 3), Unidad = ing.Unidad, Motivo = motivo, Usuario = Sesion?.Nombre ?? ""
            });
        }
        if (uso.Count > 0) { GuardarIngredientes(); GuardarMovimientos(); }
    }
    static void Descontar(Dictionary<int, double> uso, string motivo) => Mover(uso, "Salida", motivo);
    static void Devolver(Dictionary<int, double> uso, string motivo) => Mover(uso, "Entrada", motivo);

    /// <summary>Ingredientes comprometidos por platillos agregados pero aún no enviados a cocina.</summary>
    static Dictionary<int, double> Reservado()
    {
        var d = new Dictionary<int, double>();
        foreach (var c in Cuentas.Where(x => x.Estado == "Abierta"))
            foreach (var it in c.ItemsActivos.Where(i => !i.Enviado)) Sumar(d, it.ProductoId, it.Factor * it.Cantidad);
        return d;
    }

    /// <summary>falta: nombre del ingrediente que no alcanza. aviso: ingredientes que quedarían en nivel bajo.</summary>
    public static (string falta, string aviso) RevisarStock(Producto p, double factor, int cant)
    {
        var res = Reservado();
        string falta = null;
        var avisos = new List<string>();
        foreach (var r in p.Receta)
        {
            var ing = Ingredientes.FirstOrDefault(i => i.Id == r.IngredienteId);
            if (ing == null || !ing.Activo) continue;
            double need = r.Cantidad * factor * cant;
            double disp = ing.Existencia - res.GetValueOrDefault(ing.Id);
            if (need > disp + 1e-9) { falta = ing.Nombre; break; }
            if (disp - need <= ing.Minimo) avisos.Add(ing.Nombre);
        }
        return (falta, avisos.Count > 0 ? string.Join(", ", avisos.Distinct()) : null);
    }

    // ───────────── Migración de datos existentes ─────────────
    static void Migrar()
    {
        bool cambios = false;
        if (!Usuarios.Any(u => u.Rol == Roles.Cocina) && !Usuarios.Any(u => u.NombreUsuario.Equals("cocina", StringComparison.OrdinalIgnoreCase)))
        {
            var u = new Usuario { Id = Siguiente(Usuarios.Select(x => x.Id)), Nombre = "Cocina", NombreUsuario = "cocina", Rol = Roles.Cocina };
            FijarPassword(u, "cocina123");
            Usuarios.Add(u);
            GuardarUsuarios();
        }
        foreach (var c in Cuentas)
        {
            var f = $"C-{c.Id}";
            if (c.Folio != f) { c.Folio = f; cambios = true; }
            foreach (var it in c.Items)
                if (it.Enviado && string.IsNullOrEmpty(it.EstadoCocina)) { it.EstadoCocina = "Entregado"; cambios = true; }
            if (c.Estado == "Abierta" && c.MesaId == 0 && !c.Items.Any(i => i.Enviado))
            { c.Estado = "Cancelada"; c.FechaCierre = DateTime.Now; c.MotivoCancelacion = "Pedido para llevar descontinuado"; cambios = true; }
        }
        bool cortes = false;
        foreach (var k in Cortes)
        {
            var f = $"Corte-{k.Id}";
            if (k.Folio != f) { k.Folio = f; cortes = true; }
        }
        if (!Productos.Any(p => p.Nombre.Equals("Agua Natural", StringComparison.OrdinalIgnoreCase)))
        {
            Productos.Add(new Producto
            {
                Id = Siguiente(Productos.Select(x => x.Id)), Categoria = "Bebidas", Nombre = "Agua Natural",
                Descripcion = "Agua purificada.", Precio = 25, Costo = 6, Emoji = "💧"
            });
            GuardarProductos();
        }
        if (cambios) GuardarCuentas();
        if (cortes) GuardarCortes();
    }

    public static void Resumir(Corte c)
    {
        var cu = Cuentas.Where(x => x.Estado == "Pagada" && x.CorteId == c.Id).ToList();
        c.NumeroCuentas = cu.Count;
        c.TotalVentas = cu.Sum(x => x.Total);
        c.VentasEfectivo = cu.SelectMany(x => x.Pagos).Where(p => p.Metodo == "Efectivo").Sum(p => p.Monto);
        c.VentasTarjeta = cu.SelectMany(x => x.Pagos).Where(p => p.Metodo == "Tarjeta").Sum(p => p.Monto);
        c.VentasTransferencia = cu.SelectMany(x => x.Pagos).Where(p => p.Metodo == "Transferencia").Sum(p => p.Monto);
        c.Propinas = cu.Sum(x => x.Propina);
        c.Gastos = Gastos.Where(g => g.CorteId == c.Id).Sum(g => g.Monto);
        c.EfectivoEsperado = c.FondoInicial + c.VentasEfectivo - c.Gastos;
        c.Diferencia = c.Estado == "Cerrado" ? c.EfectivoContado - c.EfectivoEsperado : 0;
    }

    public static string ExportarTicket(Cuenta c) => Exportar("ticket_" + c.Folio, c);

    // ───────────── Datos iniciales ─────────────
    static int Ing(string n) => Ingredientes.First(i => i.Nombre == n).Id;
    static RecetaItem R(string n, double c) => new() { IngredienteId = Ing(n), Cantidad = c };

    static void SembrarIngredientes()
    {
        void I(string n, string u, double ex, double min, decimal costo) =>
            Ingredientes.Add(new Ingrediente { Id = Ingredientes.Count + 1, Nombre = n, Unidad = u, Existencia = ex, Minimo = min, CostoUnitario = costo });
        I("Sirloin", "kg", 25, 5, 230); I("Arrachera", "kg", 20, 5, 260); I("Costilla de res", "kg", 20, 5, 190);
        I("Carne de puerco", "kg", 15, 4, 120); I("Pechuga de pollo", "kg", 15, 4, 95); I("Camarón", "kg", 10, 3, 280);
        I("Filete de pescado", "kg", 8, 3, 150); I("Pulpo", "kg", 4, 1, 320); I("Molleja", "kg", 6, 2, 110);
        I("Tocino", "kg", 5, 1, 140); I("Queso asadero", "kg", 6, 2, 150); I("Papa", "kg", 30, 8, 25);
        I("Cebolla", "kg", 15, 4, 22); I("Pimiento", "kg", 5, 1.5, 40); I("Aguacate", "pza", 40, 10, 12);
        I("Frijoles", "kg", 15, 4, 38); I("Tortilla de harina", "pza", 300, 60, 2.5m); I("Tortilla de maíz", "pza", 400, 80, 1.2m);
        I("Tostadas", "pza", 200, 40, 1.5m); I("Salchicha polaca", "pza", 60, 15, 14); I("Pan de hamburguesa", "pza", 40, 10, 7);
        I("Carne molida de res", "kg", 8, 2, 140); I("Cerveza nacional", "pza", 240, 48, 22); I("Refresco", "pza", 150, 36, 14);
        I("Clamato", "L", 12, 3, 45); I("Limón", "kg", 12, 3, 28); I("Café de olla (grano)", "kg", 3, 0.5, 180);
        I("Base de aguas frescas", "L", 30, 8, 12); I("Lechuga y jitomate", "kg", 6, 2, 25); I("Chile seco (cascabel/ancho)", "kg", 3, 0.8, 120);
        GuardarIngredientes();
    }

    static void P(string cat, string nom, string desc, decimal precio, decimal costo, string emoji, int guarn = 0,
        RecetaItem[] receta = null, params Opcion[] opciones)
    {
        Productos.Add(new Producto
        {
            Id = Productos.Count + 1, Categoria = cat, Nombre = nom, Descripcion = desc, Precio = precio, Costo = costo,
            Emoji = emoji, Guarniciones = guarn, Receta = receta?.ToList() ?? new(), Opciones = opciones.ToList()
        });
    }
    static Opcion O(string n, decimal p, decimal c, double f = 1) => new() { Nombre = n, Precio = p, Costo = c, Factor = f };

    static void SembrarMenu()
    {
        const string T = "Carne Asada y Tacos", PA = "Parrilladas", G = "Guisados Regios", E = "Entradas y Extras", OT = "Otros Platillos", B = "Bebidas";
        P(T, "Tacos de Sirloin", "Con guacamole y cebolla asada.", 145, 60, "🌮", 0,
            new[] { R("Sirloin", .2), R("Tortilla de maíz", 4), R("Aguacate", .5), R("Cebolla", .05) });
        P(T, "Tacos de Arrachera Marinada", "Con frijoles charros y salsa tatemada.", 165, 72, "🌮", 0,
            new[] { R("Arrachera", .2), R("Tortilla de maíz", 4), R("Frijoles", .08) });
        P(T, "Alambre Regio de Res", "Con tocino, pimientos y queso asadero gratinado.", 180, 78, "🥓", 0,
            new[] { R("Sirloin", .2), R("Tocino", .05), R("Pimiento", .06), R("Queso asadero", .08), R("Tortilla de harina", 3) });
        P(T, "Burrito Norteño Gigante", "En tortilla sobaquera con frijoles con veneno y carne asada.", 150, 58, "🌯", 0,
            new[] { R("Sirloin", .15), R("Frijoles", .1), R("Tortilla de harina", 1), R("Queso asadero", .03) });

        const string pd = "Con cebolla, papa asada preparada, salchicha polaca asada, tostadas gratinadas y frijoles charros.";
        P(PA, "Parrillada de Costilla", pd, 380, 170, "🍖", 0,
            new[] { R("Costilla de res", .6), R("Papa", .4), R("Cebolla", .15), R("Salchicha polaca", 2), R("Tostadas", 4), R("Frijoles", .2), R("Queso asadero", .1) },
            O("2 personas", 380, 170), O("4 personas", 720, 320, 2));
        P(PA, "Parrillada de Arrachera", pd, 440, 200, "🥩", 0,
            new[] { R("Arrachera", .6), R("Papa", .4), R("Cebolla", .15), R("Salchicha polaca", 2), R("Tostadas", 4), R("Frijoles", .2), R("Queso asadero", .1) },
            O("2 personas", 440, 200), O("4 personas", 820, 370, 2));

        P(G, "Asado de Puerco Tradicional", "En salsa de chiles cascabel y ancho.", 90, 35, "🍲", 3,
            new[] { R("Carne de puerco", .2), R("Chile seco (cascabel/ancho)", .03) });
        P(G, "Deshebrada Norteña en Chile Rojo con Papa", "Guisado tradicional de res deshebrada.", 90, 35, "🍲", 3,
            new[] { R("Sirloin", .18), R("Papa", .1), R("Chile seco (cascabel/ancho)", .03) });

        P(E, "Molleja a la Parrilla", "", 140, 55, "🍢", 0, new[] { R("Molleja", .25) });
        P(E, "Camarones Asados a la Leña", "", 190, 95, "🦐", 0, new[] { R("Camarón", .25), R("Limón", .05) });
        P(E, "Camarones para Picar", "Al ajillo o empanizados.", 175, 88, "🍤", 0, new[] { R("Camarón", .25) },
            O("Al ajillo", 175, 88), O("Empanizados", 175, 88));
        P(E, "Papa Asada Especial con Carne Asada", "", 135, 52, "🥔", 0, new[] { R("Papa", .4), R("Sirloin", .12), R("Queso asadero", .05) });
        P(E, "Tostadas Mixtas de Mariscos", "Con pescado, camarón y pulpo.", 160, 70, "🦑", 0,
            new[] { R("Tostadas", 3), R("Filete de pescado", .08), R("Camarón", .08), R("Pulpo", .08) });

        P(OT, "Hamburguesa al Carbón Regia", "", 130, 48, "🍔", 0,
            new[] { R("Pan de hamburguesa", 1), R("Carne molida de res", .2), R("Queso asadero", .04), R("Lechuga y jitomate", .05) });
        P(OT, "Boneless de Pollo 350g", "", 140, 50, "🍗", 0, new[] { R("Pechuga de pollo", .35) });
        P(OT, "Filete de Pescado al Gusto", "", 150, 62, "🐟", 0, new[] { R("Filete de pescado", .25) });
        P(OT, "Ceviche Regio Mar y Tierra", "", 130, 52, "🥗", 0, new[] { R("Filete de pescado", .1), R("Camarón", .08), R("Limón", .1) });
        P(OT, "Chilaquiles en Salsa Verde", "", 130, 38, "🥘", 0, new[] { R("Tortilla de maíz", 6), R("Queso asadero", .05) });
        P(OT, "Pechuga Empanizada o a la Plancha", "", 130, 48, "🍗", 0, new[] { R("Pechuga de pollo", .3) },
            O("Empanizada", 130, 48), O("A la plancha", 130, 48));

        P(B, "Michelada Clásica de la Casa", "", 85, 28, "🍺", 0, new[] { R("Cerveza nacional", 1), R("Limón", .05) });
        P(B, "Michelada con Clamato Preparado", "", 95, 32, "🍹", 0, new[] { R("Cerveza nacional", 1), R("Clamato", .2), R("Limón", .05) });
        P(B, "Cervezas Nacionales", "", 45, 22, "🍻", 0, new[] { R("Cerveza nacional", 1) });
        P(B, "Refrescos de la Casa", "Coca-Cola, Joya de Manzana o Sprite.", 35, 14, "🥤", 0, new[] { R("Refresco", 1) },
            O("Coca-Cola", 35, 14), O("Joya de Manzana", 35, 14), O("Sprite", 35, 14));
        P(B, "Aguas Frescas Naturales", "Horchata artesanal, Jamaica o Limón con chía.", 40, 9, "🧃", 0, new[] { R("Base de aguas frescas", .35) },
            O("Horchata artesanal", 40, 9), O("Jamaica", 40, 9), O("Limón con chía", 40, 9));
        P(B, "Limonada Mineral o Natural", "", 45, 12, "🍋", 0, new[] { R("Limón", .1) }, O("Natural", 45, 12), O("Mineral", 45, 12));
        P(B, "Café de Olla Tradicional", "", 35, 8, "☕", 0, new[] { R("Café de olla (grano)", .02) });
    }
}
