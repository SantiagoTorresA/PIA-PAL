namespace AsaderoRegio;

public partial class App : Application
{
    public static MainWindow Ventana { get; private set; }

    public App()
    {
        InitializeComponent();
        UnhandledException += (s, e) =>
        {
            e.Handled = true;
            try
            {
                Directory.CreateDirectory(Datos.CarpetaRaiz);
                File.AppendAllText(Path.Combine(Datos.CarpetaRaiz, "errores.log"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {e.Exception}\n\n");
            }
            catch { }
            Notificador.Mostrar("Ocurrió un error inesperado: " + e.Message, false);
        };
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        Datos.Iniciar();
        Ventana = new MainWindow();
        Ventana.Activate();
    }
}
