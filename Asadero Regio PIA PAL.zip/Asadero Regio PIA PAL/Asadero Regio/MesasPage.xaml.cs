namespace AsaderoRegio;

public class MesaVM
{
    public Mesa Mesa { get; set; }
    public Cuenta Cuenta { get; set; }
    public string Emoji { get; set; }
    public string Titulo { get; set; }
    public string Linea1 { get; set; }
    public string Linea2 { get; set; }
    public Brush Fondo { get; set; }
}

public sealed partial class MesasPage : Page
{
    readonly HashSet<object> _hover = new();

    public MesasPage()
    {
        InitializeComponent();
        BtnAdmin.Visibility = Datos.Sesion.Rol == Roles.Admin ? Visibility.Visible : Visibility.Collapsed;
    }

    protected override void OnNavigatedTo(NavigationEventArgs e) => Cargar();

    void Cargar()
    {
        var lista = Datos.Mesas.Where(m => m.Activa).OrderBy(m => m.Numero).Select(Crear).ToList();
        Rejilla.ItemsSource = lista;
        int ocup = lista.Count(x => x.Cuenta != null);
        TxtResumen.Text = $"{lista.Count - ocup} libres · {ocup} ocupadas";
    }

    static MesaVM Crear(Mesa m)
    {
        var c = Datos.CuentaAbiertaDeMesa(m.Id);
        var vm = new MesaVM { Mesa = m, Cuenta = c, Titulo = $"Mesa {m.Numero}" };
        if (c == null)
        {
            vm.Emoji = "🪑"; vm.Fondo = Paleta.Verde; vm.Linea1 = $"Libre · {m.Capacidad} lugares"; vm.Linea2 = "Disponible";
        }
        else
        {
            var min = (int)(DateTime.Now - c.FechaApertura).TotalMinutes;
            var est = c.EstadoMesero;
            vm.Emoji = est switch { "En preparación" => "🔥", "Listo para entregar" => "🛎", "Entregado" => "🍽", "Por cobrar" => "🧾", _ => "📝" };
            vm.Fondo = c.ColorEstado;
            vm.Linea1 = $"{(est == "Sin pedido" ? "Ocupada" : est)} · {c.Personas} pers.";
            vm.Linea2 = $"{Fmt.Money(c.Total)} · {min} min";
        }
        return vm;
    }

    void Rejilla_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs a)
    {
        if (a.InRecycleQueue || a.Phase != 0) return;
        Anim.Enter(a.ItemContainer, a.ItemIndex * 35, 18);
        if (_hover.Add(a.ItemContainer))
        {
            a.ItemContainer.PointerEntered += (o, _) => Anim.Scale((UIElement)o, 1.06);
            a.ItemContainer.PointerExited += (o, _) => Anim.Scale((UIElement)o, 1.0);
        }
    }

    async void Rejilla_ItemClick(object sender, ItemClickEventArgs e)
    {
        var vm = (MesaVM)e.ClickedItem;
        bool esMesero = Datos.Sesion.Rol == Roles.Mesero;

        if (vm.Cuenta == null)
        {
            if (!esMesero) { Notificador.Mostrar("Solo el mesero puede abrir mesas.", false); return; }
            var personas = Campo.Num($"Número de personas (de 1 a {vm.Mesa.Capacidad})", null, true, 2);
            var err = Dialogos.EtiquetaError();
            var panel = new StackPanel { Spacing = 10, MinWidth = 320 };
            panel.Children.Add(personas); panel.Children.Add(err);
            var d = Dialogos.Nuevo(XamlRoot, $"Abrir Mesa {vm.Mesa.Numero}", panel, "Abrir cuenta");
            int n = 0;
            Dialogos.Validar(d, err, () =>
            {
                var m = Campo.Validar(personas, "Número de personas", 1, vm.Mesa.Capacidad, true, out var v);
                if (m != null) return m;
                n = (int)v; return null;
            });
            if (await d.ShowAsync() != ContentDialogResult.Primary) return;
            var c = Datos.NuevaCuenta(vm.Mesa, n);
            ShellPage.Actual.IrA("menu", c);
            return;
        }

        if (!esMesero)
        {
            await Dialogos.Info(XamlRoot, vm.Titulo, $"Estado: {vm.Cuenta.EstadoMesero}\nPersonas: {vm.Cuenta.Personas}\nCuenta: {vm.Cuenta.Folio}\nConsumo actual: {Fmt.Money(vm.Cuenta.Total)}");
            return;
        }

        var cu = vm.Cuenta;
        var dlg = new ContentDialog
        {
            XamlRoot = XamlRoot, Title = vm.Titulo, PrimaryButtonText = "Ir al menú", SecondaryButtonText = "Cerrar mesa", CloseButtonText = "Volver",
            DefaultButton = ContentDialogButton.Primary,
            IsPrimaryButtonEnabled = cu.Estado == "Abierta" && !cu.SolicitoCuenta,
            IsSecondaryButtonEnabled = !cu.ItemsActivos.Any() && cu.Pagos.Count == 0,
            Content = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Text = $"Estado: {cu.EstadoMesero}\nPersonas: {cu.Personas}\nCuenta: {cu.Folio}" +
                       (cu.ItemsActivos.Any() ? "" : "\n\nLa mesa no tiene consumo, puedes cerrarla.") +
                       (cu.SolicitoCuenta ? "\n\nLa cuenta ya está por cobrar." : "")
            }
        };
        var r = await dlg.ShowAsync();
        if (r == ContentDialogResult.Primary) ShellPage.Actual.IrA("menu", cu);
        else if (r == ContentDialogResult.Secondary)
        {
            if (Datos.CerrarMesaVacia(cu)) { Cargar(); Notificador.Mostrar($"Mesa {cu.MesaNumero} cerrada."); }
        }
    }

    async void Admin_Click(object sender, RoutedEventArgs e)
    {
        var mesas = Datos.Mesas.OrderBy(x => x.Numero).ToList();
        var combo = new ComboBox { Header = "Mesa", HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var m in mesas) combo.Items.Add($"Mesa {m.Numero}" + (m.Activa ? "" : " (inactiva)"));
        combo.Items.Add("Nueva mesa");
        combo.SelectedIndex = combo.Items.Count - 1;
        var cap = Campo.Num("Capacidad (de 1 a 10 lugares)", 4, true, 2);
        var activa = new ToggleSwitch { Header = "Mesa activa", IsOn = true };
        var err = Dialogos.EtiquetaError();
        combo.SelectionChanged += (_, _) =>
        {
            int i = combo.SelectedIndex;
            if (i >= 0 && i < mesas.Count) { cap.Text = mesas[i].Capacidad.ToString(); activa.IsOn = mesas[i].Activa; }
            else { cap.Text = "4"; activa.IsOn = true; }
        };
        var panel = new StackPanel { Spacing = 12, MinWidth = 340 };
        panel.Children.Add(combo); panel.Children.Add(cap); panel.Children.Add(activa); panel.Children.Add(err);
        var d = Dialogos.Nuevo(XamlRoot, "Administrar mesas", panel);
        int capacidad = 4;
        Dialogos.Validar(d, err, () =>
        {
            var m = Campo.Validar(cap, "Capacidad", 1, 10, true, out var v);
            if (m != null) return m;
            capacidad = (int)v;
            int i = combo.SelectedIndex;
            if (i >= 0 && i < mesas.Count && !activa.IsOn && Datos.CuentaAbiertaDeMesa(mesas[i].Id) != null)
                return "No puedes desactivar una mesa con cuenta abierta.";
            return null;
        }, () =>
        {
            int i = combo.SelectedIndex;
            if (i >= 0 && i < mesas.Count) { mesas[i].Capacidad = capacidad; mesas[i].Activa = activa.IsOn; }
            else
            {
                int n = Datos.Mesas.Any() ? Datos.Mesas.Max(x => x.Numero) + 1 : 1;
                Datos.Mesas.Add(new Mesa { Id = Datos.Siguiente(Datos.Mesas.Select(x => x.Id)), Numero = n, Capacidad = capacidad, Activa = activa.IsOn });
            }
            Datos.GuardarMesas();
        });
        if (await d.ShowAsync() == ContentDialogResult.Primary) { Cargar(); Notificador.Mostrar("Mesas actualizadas."); }
    }
}
