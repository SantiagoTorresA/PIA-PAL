namespace AsaderoRegio;

public sealed partial class CocinaPage : Page
{
    readonly HashSet<object> _hover = new();

    public CocinaPage() { InitializeComponent(); }

    protected override void OnNavigatedTo(NavigationEventArgs e) => Cargar();

    void Cargar()
    {
        var lista = Datos.Cuentas
            .Where(c => c.Estado == "Abierta" && c.ItemsActivos.Any(i => i.Enviado && (i.EstadoCocina == "Preparando" || i.EstadoCocina == "Listo")))
            .OrderBy(c => c.ItemsActivos.Any(i => i.EstadoCocina == "Preparando") ? 0 : 1)
            .ThenBy(c => c.PrimerEnvio)
            .Select(Crear).ToList();
        Rejilla.ItemsSource = lista;
        int prep = lista.Count(x => x.Cuenta.ItemsActivos.Any(i => i.EstadoCocina == "Preparando"));
        TxtResumen.Text = lista.Count == 0 ? "No hay pedidos en cocina." : $"{prep} en preparación · {lista.Count - prep} listo(s) esperando al mesero";
    }

    static CuentaVM Crear(Cuenta c)
    {
        bool prep = c.ItemsActivos.Any(i => i.EstadoCocina == "Preparando");
        var pend = c.ItemsActivos.Where(i => i.EstadoCocina == "Preparando" || i.EstadoCocina == "Listo").ToList();
        var envio = c.PrimerEnvio ?? DateTime.Now;
        return new CuentaVM
        {
            Cuenta = c, Titulo = c.Titulo, Fondo = prep ? Paleta.Rojo : Paleta.Verde,
            Emoji = prep ? "🔥" : "🛎",
            Linea1 = prep ? "En preparación" : "Listo",
            Linea2 = $"{pend.Sum(i => i.Cantidad)} platillos · hace {(int)(DateTime.Now - envio).TotalMinutes} min"
        };
    }

    void Rejilla_ContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs a)
    {
        if (a.InRecycleQueue || a.Phase != 0) return;
        Anim.Enter(a.ItemContainer, a.ItemIndex * 35, 18);
        if (_hover.Add(a.ItemContainer))
        {
            a.ItemContainer.PointerEntered += (o, _) => Anim.Scale((UIElement)o, 1.06);
            a.ItemContainer.PointerExited += (o, _) => Anim.Scale((UIElement)o, 1.0);
        }
    }

    async void Rejilla_ItemClick(object sender, ItemClickEventArgs e)
    {
        var c = ((CuentaVM)e.ClickedItem).Cuenta;
        var panel = new StackPanel { Spacing = 8, MinWidth = 460 };
        panel.Children.Add(new TextBlock { Text = $"{c.Titulo} · {c.Folio}", FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = Paleta.Amarillo });
        foreach (var it in c.ItemsActivos.Where(i => i.EstadoCocina == "Preparando" || i.EstadoCocina == "Listo"))
        {
            var sp = new StackPanel { Margin = new Thickness(0, 4, 0, 4) };
            sp.Children.Add(new TextBlock
            {
                Text = $"{it.Cantidad} × {it.Descripcion}  ({(it.EstadoCocina == "Listo" ? "listo" : "en preparación")})",
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap
            });
            if (it.Detalle != "") sp.Children.Add(new TextBlock { Text = it.Detalle, FontSize = 12, TextWrapping = TextWrapping.Wrap, Foreground = Paleta.Amarillo });
            panel.Children.Add(sp);
        }
        bool hayPrep = c.ItemsActivos.Any(i => i.EstadoCocina == "Preparando");
        if (!hayPrep) panel.Children.Add(new TextBlock { Text = "Este pedido ya está marcado como listo.", Foreground = Paleta.VerdeClaro });

        var d = Dialogos.Nuevo(XamlRoot, "Pedido en cocina", panel, "Marcar pedido como listo");
        d.CloseButtonText = "Cerrar";
        d.IsPrimaryButtonEnabled = hayPrep;
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Datos.MarcarListo(c);
        Notificador.Mostrar($"{c.Titulo}: pedido listo para entregar.");
        Cargar();
    }
}
