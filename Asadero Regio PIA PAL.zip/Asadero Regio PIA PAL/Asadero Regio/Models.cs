namespace AsaderoRegio;

public static class Roles
{
    public const string Admin = "Administrador", Cajero = "Cajero", Mesero = "Mesero", Cocina = "Cocina";
    public static readonly string[] Todos = { Admin, Cajero, Mesero, Cocina };
}

public class Usuario
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string NombreUsuario { get; set; } = "";
    public string Salt { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Rol { get; set; } = Roles.Mesero;
    public bool Activo { get; set; } = true;
    public DateTime FechaAlta { get; set; } = DateTime.Now;

    [JsonIgnore] public string EstadoTxt => Activo ? "Activo" : "Inactivo";
    [JsonIgnore] public Brush EstadoBrush => Activo ? Paleta.VerdeClaro : Paleta.RojoClaro;
    [JsonIgnore] public string Linea => $"@{NombreUsuario} · {Rol}";
}

public class Opcion
{
    public string Nombre { get; set; } = "";
    public decimal Precio { get; set; }
    public decimal Costo { get; set; }
    public double Factor { get; set; } = 1;
    public bool Activo { get; set; } = true;
}

public class RecetaItem
{
    public int IngredienteId { get; set; }
    public double Cantidad { get; set; }
}

public class CambioPrecio
{
    public DateTime Fecha { get; set; }
    public decimal Anterior { get; set; }
    public decimal Nuevo { get; set; }
    public string Usuario { get; set; } = "";
}

public class Producto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Categoria { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public string Emoji { get; set; } = "🍽";
    public decimal Precio { get; set; }
    public decimal Costo { get; set; }
    public int Guarniciones { get; set; }
    public bool Activo { get; set; } = true;
    public List<Opcion> Opciones { get; set; } = new();
    public List<RecetaItem> Receta { get; set; } = new();
    public List<CambioPrecio> HistorialPrecios { get; set; } = new();

    [JsonIgnore] public List<Opcion> OpcionesActivas => Opciones.Where(o => o.Activo).ToList();
    /// <summary>Tiene opciones pero todas están desactivadas: no se puede pedir.</summary>
    [JsonIgnore] public bool SinOpcionesDisponibles => Opciones.Count > 0 && !Opciones.Any(o => o.Activo);
    [JsonIgnore] public decimal CostoReceta => Receta.Sum(r => (Datos.Ingredientes.FirstOrDefault(i => i.Id == r.IngredienteId)?.CostoUnitario ?? 0) * (decimal)r.Cantidad);
    [JsonIgnore] public string PrecioTxt => SinOpcionesDisponibles ? "No disponible"
        : Opciones.Count > 0 ? (OpcionesActivas.Count > 1 ? "Desde " : "") + Fmt.Money(OpcionesActivas.Min(o => o.Precio)) : Fmt.Money(Precio);
    [JsonIgnore] public string EstadoTxt => Activo ? "Disponible" : "Oculto";
    [JsonIgnore] public Brush EstadoBrush => Activo ? Paleta.VerdeClaro : Paleta.RojoClaro;
    [JsonIgnore] public Brush ColorCategoria => Paleta.Categoria(Categoria);
    [JsonIgnore] public string Subtitulo => Descripcion + (Opciones.Count > 0 ? "  · Opciones: " + string.Join(" / ", Opciones.Select(o => o.Activo ? o.Nombre : o.Nombre + " (desactivada)")) : "") + (Guarniciones > 0 ? $"  · {Guarniciones} guarniciones" : "");
    [JsonIgnore] public string AvisoStock
    {
        get { var (falta, aviso) = Datos.RevisarStock(this, 1, 1); return SinOpcionesDisponibles ? "No disponible" : falta != null ? "Sin insumos" : aviso != null ? "Insumos bajos" : ""; }
    }
    [JsonIgnore] public double OpacidadTile => SinOpcionesDisponibles || Datos.RevisarStock(this, 1, 1).falta != null ? 0.45 : 1.0;
}

public class Ingrediente
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Unidad { get; set; } = "kg";
    public double Existencia { get; set; }
    public double Minimo { get; set; }
    public decimal CostoUnitario { get; set; }
    public bool Activo { get; set; } = true;

    [JsonIgnore] public bool Bajo => Existencia <= Minimo;
    [JsonIgnore] public string ExistenciaTxt => $"{Existencia:0.##} {Unidad}";
    [JsonIgnore] public string MinimoTxt => $"{Minimo:0.##} {Unidad}";
    [JsonIgnore] public string CostoTxt => Fmt.Money(CostoUnitario) + " / " + Unidad;
    [JsonIgnore] public string ValorTxt => Fmt.Money((decimal)Existencia * CostoUnitario);
    [JsonIgnore] public string EstadoTxt => !Activo ? "Inactivo" : Existencia <= 0 ? "Agotado" : Bajo ? "Stock bajo" : "Suficiente";
    [JsonIgnore] public Brush EstadoBrush => !Activo ? Paleta.Gris : Bajo ? Paleta.RojoClaro : Paleta.VerdeClaro;
}

public class MovimientoInventario
{
    public int Id { get; set; }
    public DateTime Fecha { get; set; }
    public int IngredienteId { get; set; }
    public string Ingrediente { get; set; } = "";
    public string Tipo { get; set; } = "";   // Entrada, Salida, Ajuste
    public double Cantidad { get; set; }
    public string Unidad { get; set; } = "";
    public string Motivo { get; set; } = "";
    public string Usuario { get; set; } = "";

    [JsonIgnore] public string Titulo => Ingrediente;
    [JsonIgnore] public string Detalle => $"{Tipo}: {Cantidad:0.###} {Unidad} · {Motivo}";
    [JsonIgnore] public string FechaTxt => Fmt.Fecha(Fecha) + " · " + Usuario;
}

public class Mesa
{
    public int Id { get; set; }
    public int Numero { get; set; }
    public int Capacidad { get; set; } = 4;
    public bool Activa { get; set; } = true;
}

public class ItemPedido
{
    public int Id { get; set; }
    public int ProductoId { get; set; }
    public string Nombre { get; set; } = "";
    public string Categoria { get; set; } = "";
    public string Emoji { get; set; } = "🍽";
    public string Opcion { get; set; } = "";
    public List<string> Guarniciones { get; set; } = new();
    public int Cantidad { get; set; } = 1;
    public decimal PrecioUnitario { get; set; }
    public decimal CostoUnitario { get; set; }
    public double Factor { get; set; } = 1;
    public string Notas { get; set; } = "";
    public bool Enviado { get; set; }
    public bool Cancelado { get; set; }
    public string EstadoCocina { get; set; } = "";   // "", Preparando, Listo, Entregado
    public DateTime? FechaEnvio { get; set; }

    [JsonIgnore] public decimal Importe => PrecioUnitario * Cantidad;
    [JsonIgnore] public string ImporteTxt => Fmt.Money(Importe);
    [JsonIgnore] public string Descripcion => Nombre + (Opcion != "" ? $" ({Opcion})" : "");
    [JsonIgnore] public string DescripcionMenu => $"{Emoji} {Descripcion}";
    [JsonIgnore] public string CantidadTxt => Cantidad.ToString();
    [JsonIgnore] public string PrecioTxt => $"{Cantidad} × {Fmt.Money(PrecioUnitario)}";
    [JsonIgnore] public bool Editable => !Enviado;
    [JsonIgnore] public string Detalle
    {
        get
        {
            var l = new List<string>();
            if (Guarniciones.Count > 0) l.Add("Guarniciones: " + string.Join(", ", Guarniciones));
            if (!string.IsNullOrWhiteSpace(Notas)) l.Add("Nota: " + Notas);
            return string.Join("\n", l);
        }
    }
    [JsonIgnore] public Visibility DetalleVis => string.IsNullOrEmpty(Detalle) ? Visibility.Collapsed : Visibility.Visible;
    [JsonIgnore] public string EstadoTexto => !Enviado ? "Sin enviar" : EstadoCocina == "Preparando" ? "En preparación" : EstadoCocina == "Listo" ? "Listo" : "Entregado";
    [JsonIgnore] public string EstadoIcono => !Enviado ? "🕒" : EstadoCocina == "Preparando" ? "🍳" : EstadoCocina == "Listo" ? "🛎" : "🍽";
}

public class Pago
{
    public DateTime Fecha { get; set; } = DateTime.Now;
    public string Metodo { get; set; } = "Efectivo";
    public decimal Monto { get; set; }
    public decimal Recibido { get; set; }
    public decimal Cambio { get; set; }
    public string Referencia { get; set; } = "";
    public string Usuario { get; set; } = "";

    [JsonIgnore] public string Resumen =>
        $"{Metodo}: {Fmt.Money(Monto)}" + (Cambio > 0 ? $"  (recibido {Fmt.Money(Recibido)}, cambio {Fmt.Money(Cambio)})" : "");
}

public class Cuenta
{
    public int Id { get; set; }
    public string Folio { get; set; } = "";
    public int MesaId { get; set; }
    public int MesaNumero { get; set; }
    public int Personas { get; set; } = 1;
    public string Mesero { get; set; } = "";
    public string Cajero { get; set; } = "";
    public string Estado { get; set; } = "Abierta";   // Abierta, Pagada, Cancelada
    public bool SolicitoCuenta { get; set; }
    public DateTime FechaApertura { get; set; } = DateTime.Now;
    public DateTime? FechaCierre { get; set; }
    public decimal DescuentoPct { get; set; }
    public decimal PropinaPct { get; set; }
    public string MotivoCancelacion { get; set; } = "";
    public int CorteId { get; set; }
    public List<ItemPedido> Items { get; set; } = new();
    public List<Pago> Pagos { get; set; } = new();

    [JsonIgnore] public IEnumerable<ItemPedido> ItemsActivos => Items.Where(i => !i.Cancelado);
    [JsonIgnore] public decimal Subtotal => ItemsActivos.Sum(i => i.Importe);
    [JsonIgnore] public decimal Descuento => Math.Round(Subtotal * DescuentoPct / 100m, 2);
    [JsonIgnore] public decimal VentaNeta => Subtotal - Descuento;
    [JsonIgnore] public decimal Propina => Math.Round(VentaNeta * PropinaPct / 100m, 2);
    [JsonIgnore] public decimal Total => VentaNeta + Propina;
    [JsonIgnore] public decimal Pagado => Pagos.Sum(p => p.Monto);
    [JsonIgnore] public decimal Pendiente => Math.Max(0, Total - Pagado);
    [JsonIgnore] public decimal Costo => ItemsActivos.Sum(i => i.CostoUnitario * i.Cantidad);
    [JsonIgnore] public string Titulo => MesaNumero == 0 ? "Sin mesa" : $"Mesa {MesaNumero}";
    [JsonIgnore] public string Resumen => $"{Titulo} · {Folio} · {Fmt.Money(Total)}";
    [JsonIgnore] public string TotalTxt => Fmt.Money(Total);
    [JsonIgnore] public string FechaTxt => Fmt.Fecha(FechaCierre ?? FechaApertura);

    [JsonIgnore] public string EstadoMesero
    {
        get
        {
            if (Estado != "Abierta") return Estado;
            if (SolicitoCuenta) return "Por cobrar";
            var env = ItemsActivos.Where(i => i.Enviado).ToList();
            if (env.Any(i => i.EstadoCocina == "Preparando")) return "En preparación";
            if (env.Any(i => i.EstadoCocina == "Listo")) return "Listo para entregar";
            if (ItemsActivos.Any(i => !i.Enviado)) return "Sin enviar";
            if (env.Count > 0) return "Entregado";
            return "Sin pedido";
        }
    }
    [JsonIgnore] public bool PuedeEntregar => EstadoMesero == "Listo para entregar";
    [JsonIgnore] public bool PuedeCobrar => EstadoMesero == "Entregado";
    [JsonIgnore] public string EstadoTxt => EstadoMesero;
    [JsonIgnore] public Brush ColorEstado => EstadoMesero switch
    {
        "En preparación" => Paleta.Rojo,
        "Listo para entregar" => Paleta.Verde,
        "Entregado" => Paleta.Azul,
        "Por cobrar" => Paleta.Morado,
        "Pagada" => Paleta.Verde,
        "Cancelada" => Paleta.Gris,
        _ => Paleta.GrisCalido
    };
    [JsonIgnore] public Brush EstadoBrush => Estado == "Pagada" ? Paleta.VerdeClaro : Estado == "Cancelada" ? Paleta.RojoClaro : Estado == "Abierta" && SolicitoCuenta ? Paleta.Amarillo : Paleta.Naranja;
    [JsonIgnore] public DateTime? PrimerEnvio => Items.Where(i => i.FechaEnvio.HasValue).Select(i => i.FechaEnvio).Min();
}

public class Corte
{
    public int Id { get; set; }
    public string Folio { get; set; } = "";
    public DateTime FechaApertura { get; set; } = DateTime.Now;
    public DateTime? FechaCierre { get; set; }
    public string Usuario { get; set; } = "";
    public string Estado { get; set; } = "Abierto";   // Abierto, Cerrado
    public decimal FondoInicial { get; set; }
    public decimal VentasEfectivo { get; set; }
    public decimal VentasTarjeta { get; set; }
    public decimal VentasTransferencia { get; set; }
    public decimal Propinas { get; set; }
    public decimal Gastos { get; set; }
    public decimal TotalVentas { get; set; }
    public int NumeroCuentas { get; set; }
    public decimal EfectivoEsperado { get; set; }
    public decimal EfectivoContado { get; set; }
    public decimal Diferencia { get; set; }
    public string Notas { get; set; } = "";

    [JsonIgnore] public string Periodo => $"{Fmt.Fecha(FechaApertura)} → {(FechaCierre.HasValue ? Fmt.Fecha(FechaCierre.Value) : "abierto")}";
    [JsonIgnore] public string TotalTxt => Fmt.Money(TotalVentas);
    [JsonIgnore] public string DifTxt => Math.Abs(Diferencia) < 0.01m ? "Cuadra" : Diferencia > 0 ? "Sobrante " + Fmt.Money(Diferencia) : "Faltante " + Fmt.Money(-Diferencia);
    [JsonIgnore] public Brush DifBrush => Math.Abs(Diferencia) < 0.01m ? Paleta.VerdeClaro : Diferencia > 0 ? Paleta.Amarillo : Paleta.RojoClaro;
    [JsonIgnore] public string Linea => $"{NumeroCuentas} cuentas · {Usuario}";
}

public class Gasto
{
    public int Id { get; set; }
    public DateTime Fecha { get; set; } = DateTime.Now;
    public string Concepto { get; set; } = "";
    public decimal Monto { get; set; }
    public int CorteId { get; set; }
    public string Usuario { get; set; } = "";

    [JsonIgnore] public string Linea => $"{Concepto}: {Fmt.Money(Monto)}";
    [JsonIgnore] public string FechaTxt => Fmt.Fecha(Fecha) + " · " + Usuario;
}

public class Configuracion
{
    public string Negocio { get; set; } = "Asadero Regio";
    public List<string> Guarniciones { get; set; } = new();
}

public class CuentaVM
{
    public Cuenta Cuenta { get; set; }
    public string Emoji { get; set; }
    public string Titulo { get; set; }
    public string Linea1 { get; set; }
    public string Linea2 { get; set; }
    public Brush Fondo { get; set; }
}
