namespace AsaderoRegio;

public sealed partial class CuentasPage : Page
{
    Cuenta _cuenta;
    bool _cargando;

    public CuentasPage()
    {
        InitializeComponent();
        Campo.SoloNumeros(TbPropina, false, 5);
        TbPropina.TextChanged += Propina_TextChanged;
        CdpDesde.Date = DateTimeOffset.Now;
        CdpHasta.Date = DateTimeOffset.Now;
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        RbModo.SelectedIndex = 0;
        CargarLista();
        Anim.Enter(PanelIzq, 0);
        Anim.Enter(PanelDer, 120);
    }

    bool Historial => RbModo.SelectedIndex == 1;

    void CargarLista()
    {
        _cargando = true;
        PanelFiltros.Visibility = Historial ? Visibility.Visible : Visibility.Collapsed;
        List<Cuenta> l;
        if (!Historial)
            l = Datos.Cuentas.Where(c => c.Estado == "Abierta" && c.SolicitoCuenta).OrderBy(c => c.FechaApertura).ToList();
        else
        {
            var d = CdpDesde.Date?.Date ?? DateTime.MinValue;
            var h = CdpHasta.Date?.Date.AddDays(1) ?? DateTime.MaxValue;
            l = Datos.Cuentas.Where(c => c.Estado != "Abierta" && (c.FechaCierre ?? c.FechaApertura) >= d && (c.FechaCierre ?? c.FechaApertura) < h)
                .OrderByDescending(c => c.FechaCierre ?? c.FechaApertura).ToList();
        }
        Lista.ItemsSource = l;
        _cargando = false;
        _cuenta = null;
        Mostrar();
    }

    void RbModo_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (Lista != null) CargarLista(); }
    void Buscar_Click(object sender, RoutedEventArgs e)
    {
        if (CdpDesde.Date.HasValue && CdpHasta.Date.HasValue && CdpDesde.Date.Value.Date > CdpHasta.Date.Value.Date)
        { Notificador.Mostrar("La fecha inicial no puede ser mayor a la final.", false); return; }
        CargarLista();
    }

    void VerTodas_Click(object sender, RoutedEventArgs e)
    {
        CdpDesde.Date = null; CdpHasta.Date = null;
        CargarLista();
    }

    void Lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_cargando) return;
        _cuenta = Lista.SelectedItem as Cuenta;
        Mostrar();
        if (_cuenta != null) Anim.Enter(PanelDetalle, 0, 14);
    }

    void Mostrar()
    {
        _cargando = true;
        if (_cuenta == null)
        {
            PanelDetalle.Visibility = Visibility.Collapsed;
            PanelVacio.Visibility = Visibility.Visible;
            _cargando = false;
            return;
        }
        PanelDetalle.Visibility = Visibility.Visible;
        PanelVacio.Visibility = Visibility.Collapsed;
        bool abierta = _cuenta.Estado == "Abierta";
        TxtDetTitulo.Text = $"{_cuenta.Titulo} · {_cuenta.Folio}";
        TxtDetSub.Text = $"Abierta: {Fmt.Fecha(_cuenta.FechaApertura)} · Atiende: {_cuenta.Mesero}" +
            (_cuenta.FechaCierre.HasValue ? $" · Cierre: {Fmt.Fecha(_cuenta.FechaCierre.Value)}" : "") + $" · Estado: {_cuenta.EstadoTxt}";
        ListaItems.ItemsSource = _cuenta.ItemsActivos.ToList();
        TbPropina.Text = _cuenta.PropinaPct == 0 ? "" : _cuenta.PropinaPct.ToString("0.##", CultureInfo.InvariantCulture);
        TbPropina.IsEnabled = BtnP5.IsEnabled = BtnP10.IsEnabled = BtnP15.IsEnabled = BtnP20.IsEnabled = abierta && _cuenta.Pagos.Count == 0;
        TxtMotivo.Text = _cuenta.Estado == "Cancelada" ? "Motivo de cancelación: " + _cuenta.MotivoCancelacion : "";
        _cargando = false;
        Totales();
    }

    void Totales()
    {
        bool abierta = _cuenta.Estado == "Abierta";
        TxtSubtotal.Text = Fmt.Money(_cuenta.Subtotal);
        TxtPropina.Text = Fmt.Money(_cuenta.Propina);
        TxtTotal.Text = Fmt.Money(_cuenta.Total);
        TxtPagado.Text = Fmt.Money(_cuenta.Pagado);
        TxtPendiente.Text = Fmt.Money(_cuenta.Pendiente);
        ListaPagos.ItemsSource = _cuenta.Pagos.ToList();
        bool liquidada = _cuenta.Pendiente <= 0.009m && _cuenta.Pagos.Count > 0 && _cuenta.Total > 0;
        // "Registrar pago" mientras falte cobrar; "Cerrar cuenta" solo aparece cuando ya se pagó
        BtnPago.Visibility = abierta && !liquidada ? Visibility.Visible : Visibility.Collapsed;
        BtnCerrar.Visibility = abierta && liquidada ? Visibility.Visible : Visibility.Collapsed;
        BtnCancelar.Visibility = abierta && _cuenta.Pagos.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    void Propina_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_cargando || _cuenta == null || _cuenta.Estado != "Abierta") return;
        var txt = (TbPropina.Text ?? "").Trim();
        decimal pct = 0;
        if (txt.Length > 0)
        {
            if (!decimal.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out pct)) pct = 0;
            if (pct > 100) { pct = 100; _cargando = true; TbPropina.Text = "100"; _cargando = false; }
        }
        _cuenta.PropinaPct = pct;
        Datos.GuardarCuentas();
        Totales();
        Anim.Pop(TxtTotal);
    }

    void Propina_Click(object sender, RoutedEventArgs e) => TbPropina.Text = (string)((Button)sender).Tag;

    async void Pago_Click(object sender, RoutedEventArgs e)
    {
        if (_cuenta == null) return;
        if (Datos.CorteAbierto == null)
        {
            if (await Dialogos.Confirmar(XamlRoot, "Caja cerrada", "Para cobrar primero debes abrir la caja. ¿Ir a Corte de caja?", "Ir a caja", "Ahora no"))
                ShellPage.Actual.IrA("corte");
            return;
        }
        if (_cuenta.Pendiente <= 0.009m) { Notificador.Mostrar("La cuenta ya está liquidada.", false); return; }

        var metodo = new ComboBox { Header = "Método de pago", HorizontalAlignment = HorizontalAlignment.Stretch };
        metodo.Items.Add("Efectivo"); metodo.Items.Add("Tarjeta");
        metodo.SelectedIndex = 0;
        var monto = Campo.Num("Monto recibido (MXN)", (double)_cuenta.Pendiente, false, 9);
        var info = new TextBlock { Text = $"Pendiente: {Fmt.Money(_cuenta.Pendiente)}", FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = Paleta.Amarillo };
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 12, MinWidth = 360 };
        panel.Children.Add(info); panel.Children.Add(metodo); panel.Children.Add(monto); panel.Children.Add(err);

        Pago pago = null;
        var d = Dialogos.Nuevo(XamlRoot, "Registrar pago", panel, "Cobrar");
        Dialogos.Validar(d, err, () => Campo.Positivo(monto, "Monto recibido", out _), () =>
        {
            var recibido = Campo.Dec(monto);
            var aplicado = Math.Min(recibido, _cuenta.Pendiente);
            var m = (string)metodo.SelectedItem;
            pago = new Pago
            {
                Metodo = m, Monto = aplicado, Usuario = Datos.Sesion.Nombre,
                Recibido = m == "Efectivo" ? recibido : aplicado,
                Cambio = m == "Efectivo" ? recibido - aplicado : 0
            };
        });
        if (await d.ShowAsync() != ContentDialogResult.Primary || pago == null) return;
        _cuenta.Pagos.Add(pago);
        Datos.GuardarCuentas();
        TbPropina.IsEnabled = BtnP5.IsEnabled = BtnP10.IsEnabled = BtnP15.IsEnabled = BtnP20.IsEnabled = false;
        Totales();
        Anim.Pop(TxtPagado);
        if (pago.Cambio > 0) await Dialogos.Info(XamlRoot, "Cambio", $"Entrega cambio: {Fmt.Money(pago.Cambio)}");
        else Notificador.Mostrar("Pago registrado.");
    }

    async void Cerrar_Click(object sender, RoutedEventArgs e)
    {
        if (_cuenta == null) return;
        if (Datos.CorteAbierto == null) { Notificador.Mostrar("Abre la caja para cerrar cuentas.", false); return; }
        if (_cuenta.Pendiente > 0.009m) { Notificador.Mostrar($"Falta cobrar {Fmt.Money(_cuenta.Pendiente)}.", false); return; }
        if (!await Dialogos.Confirmar(XamlRoot, "Cerrar cuenta", $"¿Cerrar la cuenta {_cuenta.Folio}?", "Cerrar cuenta", "Volver")) return;
        Datos.CerrarCuenta(_cuenta);
        Notificador.Mostrar($"Cuenta {_cuenta.Folio} cerrada.");
        CargarLista();
    }

    async void Cancelar_Click(object sender, RoutedEventArgs e)
    {
        if (_cuenta == null) return;
        if (_cuenta.Pagos.Count > 0) { Notificador.Mostrar("No se puede cancelar una cuenta con pagos registrados.", false); return; }
        var motivo = Campo.Texto("Motivo de cancelación (obligatorio)", "", "Escribe el motivo y presiona Enter");
        var err = Dialogos.EtiquetaError();
        var panel = new StackPanel { Spacing = 10, MinWidth = 340 };
        panel.Children.Add(motivo); panel.Children.Add(err);
        var d = Dialogos.Nuevo(XamlRoot, "Cancelar cuenta", panel, "Cancelar cuenta");
        Dialogos.Validar(d, err, () => string.IsNullOrWhiteSpace(motivo.Text) ? "Escribe el motivo." : null, () =>
            Datos.CancelarCuenta(_cuenta, motivo.Text.Trim()));
        if (await d.ShowAsync() != ContentDialogResult.Primary) return;
        Notificador.Mostrar("Cuenta cancelada.");
        CargarLista();
    }

    async void ExportarTodas_Click(object sender, RoutedEventArgs e)
    {
        var l = (Lista.ItemsSource as IEnumerable<Cuenta>)?.ToList() ?? new List<Cuenta>();
        if (l.Count == 0) { Notificador.Mostrar("No hay cuentas en la lista para exportar.", false); return; }
        string etiqueta = Historial
            ? (CdpDesde.Date.HasValue || CdpHasta.Date.HasValue
                ? $"historial_{(CdpDesde.Date.HasValue ? CdpDesde.Date.Value.ToString("yyyyMMdd") : "inicio")}_a_{(CdpHasta.Date.HasValue ? CdpHasta.Date.Value.ToString("yyyyMMdd") : "hoy")}"
                : "historial_todas")
            : "por_cobrar";
        var r = Datos.ExportarCuentas(l, etiqueta);
        if (await Dialogos.Confirmar(XamlRoot, $"{l.Count} cuentas exportadas", "Se guardaron:\n" + string.Join("\n", r), "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(r[0]);
    }

    async void Ticket_Click(object sender, RoutedEventArgs e)
    {
        if (_cuenta == null) return;
        var ruta = Datos.ExportarTicket(_cuenta);
        if (await Dialogos.Confirmar(XamlRoot, "Ticket exportado", "Se guardó el ticket en:\n" + ruta, "Abrir carpeta", "Cerrar"))
            Datos.AbrirCarpeta(ruta);
    }
}
