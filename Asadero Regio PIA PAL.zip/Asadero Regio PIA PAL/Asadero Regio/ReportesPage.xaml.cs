namespace AsaderoRegio;

public class KpiVM { public string Titulo { get; set; } public string Valor { get; set; } public Brush Fondo { get; set; } }
public class BarraVM { public string Etiqueta { get; set; } public string Valor { get; set; } public double Pct { get; set; } }

public sealed partial class ReportesPage : Page
{
    object _ultimo;

    public ReportesPage()
    {
        InitializeComponent();
        var hoy = DateTimeOffset.Now;
        CdpDesde.Date = new DateTimeOffset(new DateTime(hoy.Year, hoy.Month, 1));
        CdpHasta.Date = hoy;
    }

    protected override void OnNavigatedTo(NavigationEventArgs e) { Generar(); Anim.Enter(Kpis, 0); }

    void Generar_Click(object sender, RoutedEventArgs e) => Generar();

    void Preset_Click(object sender, RoutedEventArgs e)
    {
        var t = (string)((Button)sender).Tag;
        var hoy = DateTime.Today;
        DateTime d = t switch
        {
            "0" => hoy,
            "7" => hoy.AddDays(-6),
            "mes" => new DateTime(hoy.Year, hoy.Month, 1),
            _ => Datos.Cuentas.Where(c => c.Estado == "Pagada").Select(c => (c.FechaCierre ?? c.FechaApertura).Date).DefaultIfEmpty(hoy).Min()
        };
        CdpDesde.Date = new DateTimeOffset(d);
        CdpHasta.Date = new DateTimeOffset(hoy);
        Generar();
    }

    static List<BarraVM> Barras(IEnumerable<(string etiqueta, decimal valor, string texto)> datos)
    {
        var l = datos.ToList();
        var max = l.Count > 0 ? l.Max(x => x.valor) : 0;
        return l.Select(x => new BarraVM { Etiqueta = x.etiqueta, Valor = x.texto, Pct = max > 0 ? (double)(x.valor / max * 100) : 0 }).ToList();
    }

    void Generar()
    {
        var desde = CdpDesde.Date?.Date ?? DateTime.Today;
        var hasta = (CdpHasta.Date?.Date ?? DateTime.Today).AddDays(1);
        var cuentas = Datos.Cuentas.Where(c => c.Estado == "Pagada" && (c.FechaCierre ?? c.FechaApertura) >= desde && (c.FechaCierre ?? c.FechaApertura) < hasta).ToList();
        var gastos = Datos.Gastos.Where(g => g.Fecha >= desde && g.Fecha < hasta).Sum(g => g.Monto);

        decimal ventas = cuentas.Sum(c => c.VentaNeta), costo = cuentas.Sum(c => c.Costo), propinas = cuentas.Sum(c => c.Propina);
        decimal bruta = ventas - costo, neta = bruta - gastos;
        int n = cuentas.Count;

        Kpis.ItemsSource = new List<KpiVM>
        {
            new() { Titulo = "Ventas (sin propina)", Valor = Fmt.Money(ventas), Fondo = Paleta.Hex("C0392B") },
            new() { Titulo = "Costo de producción", Valor = Fmt.Money(costo), Fondo = Paleta.Hex("A0522D") },
            new() { Titulo = "Ganancia bruta", Valor = Fmt.Money(bruta), Fondo = Paleta.Hex("1E8E5A") },
            new() { Titulo = "Gastos / retiros", Valor = Fmt.Money(gastos), Fondo = Paleta.Hex("7B4FD1") },
            new() { Titulo = "Ganancia neta", Valor = Fmt.Money(neta), Fondo = Paleta.Hex("D35400") },
            new() { Titulo = "Cuentas cobradas", Valor = n.ToString(), Fondo = Paleta.Hex("1F77B4") },
            new() { Titulo = "Propinas", Valor = Fmt.Money(propinas), Fondo = Paleta.Hex("B7791F") },
        };

        var porDia = cuentas.GroupBy(c => (c.FechaCierre ?? c.FechaApertura).Date).OrderBy(g => g.Key)
            .Select(g => (Fmt.Dia(g.Key), g.Sum(c => c.VentaNeta), Fmt.Money(g.Sum(c => c.VentaNeta)))).ToList();
        var items = cuentas.SelectMany(c => c.ItemsActivos).ToList();
        var top = items.GroupBy(i => i.Nombre).Select(g => new { g.Key, Cant = g.Sum(i => i.Cantidad), Imp = g.Sum(i => i.Importe) })
            .OrderByDescending(x => x.Cant).Take(10).ToList();
        var cat = items.GroupBy(i => i.Categoria).Select(g => (g.Key, g.Sum(i => i.Importe), Fmt.Money(g.Sum(i => i.Importe)))).OrderByDescending(x => x.Item2).ToList();
        var met = cuentas.SelectMany(c => c.Pagos).GroupBy(p => p.Metodo).Select(g => (g.Key, g.Sum(p => p.Monto), Fmt.Money(g.Sum(p => p.Monto)))).OrderByDescending(x => x.Item2).ToList();

        LstDias.ItemsSource = Barras(porDia);
        LstTop.ItemsSource = Barras(top.Select(x => (x.Key, (decimal)x.Cant, $"{x.Cant} pzas · {Fmt.Money(x.Imp)}")));
        LstCat.ItemsSource = Barras(cat);
        LstMetodo.ItemsSource = Barras(met);

        _ultimo = new
        {
            Desde = desde, Hasta = hasta.AddDays(-1), Generado = DateTime.Now,
            Resumen = new { Ventas = ventas, Costo = costo, GananciaBruta = bruta, Gastos = gastos, GananciaNeta = neta, Propinas = propinas, Cuentas = n },
            VentasPorDia = porDia.Select(x => new { Dia = x.Item1, Ventas = x.Item2 }),
            TopProductos = top, PorCategoria = cat.Select(x => new { Categoria = x.Key, Ventas = x.Item2 }),
            PorMetodoPago = met.Select(x => new { Metodo = x.Key, Monto = x.Item2 })
        };
    }

    async void Exportar_Click(object sender, RoutedEventArgs e)
    {
        if (_ultimo == null) Generar();
        var ruta = Datos.Exportar("reporte_ventas", _ultimo);
        if (await Dialogos.Confirmar(XamlRoot, "Reporte exportado", ruta, "Abrir carpeta", "Cerrar")) Datos.AbrirCarpeta(ruta);
    }
}
