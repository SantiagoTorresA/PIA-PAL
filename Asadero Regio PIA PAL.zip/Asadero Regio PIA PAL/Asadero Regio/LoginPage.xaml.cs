using Windows.System;

namespace AsaderoRegio;

public sealed partial class LoginPage : Page
{
    public LoginPage()
    {
        InitializeComponent();
        Loaded += (_, _) =>
        {
            Anim.Enter(Tarjeta, 0, 50);
            Anim.Pulse(LogoGrid, 1.05, 1500);
            GenerarBrasas();
            TxtUsuario.Focus(FocusState.Programmatic);
        };
    }

    void Logo_ImageFailed(object sender, ExceptionRoutedEventArgs e)
    {
        LogoGrid.Visibility = Visibility.Collapsed;
    }

    void Campo_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.Enter) Entrar();
    }

    void BtnEntrar_Click(object sender, RoutedEventArgs e) => Entrar();

    void Entrar()
    {
        var u = Datos.Login(TxtUsuario.Text, TxtPass.Password);
        if (u == null)
        {
            TxtError.Text = "Usuario o contraseña incorrectos.";
            TxtError.Visibility = Visibility.Visible;
            TxtPass.Password = "";
            Anim.Shake(Tarjeta);
            return;
        }
        Datos.Sesion = u;
        MainWindow.Actual.IrAShell();
    }

    void GenerarBrasas()
    {
        var rnd = new Random();
        double w = Math.Max(ActualWidth, 1200), h = Math.Max(ActualHeight, 800);
        string[] colores = { "FFC93C", "FF7A1A", "E63B2E" };
        for (int i = 0; i < 28; i++)
        {
            double s = rnd.Next(4, 12);
            var e = new Microsoft.UI.Xaml.Shapes.Ellipse { Width = s, Height = s, Fill = Paleta.Hex(colores[i % 3]), Opacity = 0 };
            Canvas.SetLeft(e, rnd.NextDouble() * w);
            Canvas.SetTop(e, h);
            var ct = new CompositeTransform();
            e.RenderTransform = ct;
            Brasas.Children.Add(e);

            var dur = TimeSpan.FromSeconds(5 + rnd.NextDouble() * 6);
            var begin = TimeSpan.FromSeconds(rnd.NextDouble() * 6);
            var sb = new Storyboard();

            var sube = new DoubleAnimation { From = 0, To = -(h * 0.9), Duration = dur, BeginTime = begin, RepeatBehavior = RepeatBehavior.Forever };
            Storyboard.SetTarget(sube, ct); Storyboard.SetTargetProperty(sube, "TranslateY");

            var balanceo = new DoubleAnimation
            {
                From = 0, To = (rnd.NextDouble() - 0.5) * 120, Duration = dur, BeginTime = begin,
                AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever
            };
            Storyboard.SetTarget(balanceo, ct); Storyboard.SetTargetProperty(balanceo, "TranslateX");

            var fade = new DoubleAnimationUsingKeyFrames { BeginTime = begin, RepeatBehavior = RepeatBehavior.Forever };
            fade.KeyFrames.Add(new LinearDoubleKeyFrame { KeyTime = TimeSpan.Zero, Value = 0 });
            fade.KeyFrames.Add(new LinearDoubleKeyFrame { KeyTime = TimeSpan.FromSeconds(dur.TotalSeconds * 0.15), Value = 0.9 });
            fade.KeyFrames.Add(new LinearDoubleKeyFrame { KeyTime = dur, Value = 0 });
            Storyboard.SetTarget(fade, e); Storyboard.SetTargetProperty(fade, "Opacity");

            sb.Children.Add(sube); sb.Children.Add(balanceo); sb.Children.Add(fade);
            sb.Begin();
        }
    }
}
