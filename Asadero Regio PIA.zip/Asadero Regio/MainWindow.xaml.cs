using Microsoft.UI.Windowing;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace AsaderoRegio;

public sealed partial class MainWindow : Window
{
    public static MainWindow Actual { get; private set; }

    public MainWindow()
    {
        InitializeComponent();
        Actual = this;
        Title = "Asadero Regio — Punto de venta y administración";
        AppWindow.Resize(new Windows.Graphics.SizeInt32(1440, 900));
        if (AppWindow.Presenter is OverlappedPresenter p) p.Maximize();
        RaizFrame.Navigate(typeof(LoginPage));
        _ = PonerIconoAsync();
    }

    public void IrAShell()
    {
        RaizFrame.Navigate(typeof(ShellPage), null, new DrillInNavigationTransitionInfo());
        RaizFrame.BackStack.Clear();
    }

    public void IrALogin()
    {
        Datos.Sesion = null;
        RaizFrame.Navigate(typeof(LoginPage), null, new EntranceNavigationTransitionInfo());
        RaizFrame.BackStack.Clear();
    }

    /// <summary>Genera el icono de la ventana/barra de tareas a partir de Assets\icono.png (la casa). El logo con texto es Assets\logo.png.</summary>
    async Task PonerIconoAsync()
    {
        try
        {
            var png = Path.Combine(AppContext.BaseDirectory, "Assets", "icono.png");
            if (!File.Exists(png)) return;
            var file = await Windows.Storage.StorageFile.GetFileFromPathAsync(png);
            using var s = await file.OpenReadAsync();
            var dec = await BitmapDecoder.CreateAsync(s);
            double esc = Math.Min(256.0 / dec.PixelWidth, 256.0 / dec.PixelHeight);
            uint sw = (uint)Math.Max(1, Math.Round(dec.PixelWidth * esc));
            uint sh = (uint)Math.Max(1, Math.Round(dec.PixelHeight * esc));
            var tr = new BitmapTransform { ScaledWidth = sw, ScaledHeight = sh, InterpolationMode = BitmapInterpolationMode.Fant };
            var px = await dec.GetPixelDataAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Straight, tr,
                ExifOrientationMode.IgnoreExifOrientation, ColorManagementMode.DoNotColorManage);
            var src = px.DetachPixelData();
            var dst = new byte[256 * 256 * 4];
            int ox = (int)((256 - sw) / 2), oy = (int)((256 - sh) / 2);
            for (int y = 0; y < sh; y++)
                Buffer.BlockCopy(src, (int)(y * sw * 4), dst, ((y + oy) * 256 + ox) * 4, (int)sw * 4);

            using var ms = new InMemoryRandomAccessStream();
            var enc = await BitmapEncoder.CreateAsync(BitmapEncoder.PngEncoderId, ms);
            enc.SetPixelData(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Straight, 256, 256, 96, 96, dst);
            await enc.FlushAsync();
            var bytes = new byte[ms.Size];
            using (var rd = new DataReader(ms.GetInputStreamAt(0)))
            {
                await rd.LoadAsync((uint)ms.Size);
                rd.ReadBytes(bytes);
            }

            using var o = new MemoryStream();
            var w = new BinaryWriter(o);
            w.Write((short)0); w.Write((short)1); w.Write((short)1);          // cabecera ICO, 1 imagen
            w.Write((byte)0); w.Write((byte)0); w.Write((byte)0); w.Write((byte)0);   // 256x256
            w.Write((short)1); w.Write((short)32); w.Write(bytes.Length); w.Write(22);
            w.Write(bytes);
            w.Flush();
            Directory.CreateDirectory(Datos.CarpetaRaiz);
            var ico = Path.Combine(Datos.CarpetaRaiz, "logo.ico");
            File.WriteAllBytes(ico, o.ToArray());
            AppWindow.SetIcon(ico);
        }
        catch { }
    }
}
