# Asadero Regio — POS y administración (C# · WinUI 3 · JSON)

## Cómo abrirlo
1. Visual Studio 2026 con la carga de trabajo "Desarrollo de aplicaciones de escritorio con .NET".
2. Abrir `AsaderoRegio.sln`, plataforma **x64**, F5.
3. Logo: Assets\logo.png (login, menu, marca de agua). Icono de barra de tareas: Assets\icono.png y Assets\logo.ico (la casa con fondo negro).

## Usuarios iniciales (cámbialos en "Mi contraseña")
admin / admin123 · cajero / cajero123 · mesero / mesero123 · cocina / cocina123

## Datos
JSON en `Documentos\AsaderoRegio\Datos`. Exportaciones en `Exportaciones\aaaa-mm-dd\`. Respaldos en `Respaldos`.
